#########################################################################+
# DML: XGBoost
#########################################################################+

#-------------------------------------------------------------------
# DATA PREPARATION #####
#-------------------------------------------------------------------

source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)

cpx_hd <- read_csv("a_microdata/temp/cpx_hd.csv")
cpx_hd <- cpx_hd %>% arrange(gvkey, fyear)
pdim(cpx_hd)

#-------------------------------------------------------------------
# 1. DoubleML #####
#-------------------------------------------------------------------

## 1.1 Preparing the object ####

data_dml = DoubleMLData$new(
  data = data.table::as.data.table(cpx_hd),
  y_col = "RD_to_Assets",
  d_cols = "ROA",
  x_cols = colnames(cpx_hd)[c(5:ncol(cpx_hd))]
)

## 2.1 Run the XGBoost ####

set.seed(123)
# Set the parameters for penalization for g() and m()
boost = lrn("regr.xgboost",objective = "reg:squarederror",
            eta = 0.15, nrounds = 100, max_depth= 5)

# Apply this to the respective nuisence functions
dml_plr_boost = DoubleMLPLR$new(data_dml, ml_l = boost, ml_m = boost,
                                n_folds = 3)

set.seed(123)
dml_plr_boost$fit(store_predictions = TRUE)
gc()

ROA_dml_sum <- dml_plr_boost$summary()
ROA_dml_rmse_l <- as.matrix(RMSE(dml_plr_boost$predictions$ml_l,Y))
colnames(ROA_dml_rmse_l) <- c("RMSE_l")
ROA_dml_rmse_m <- as.matrix(RMSE(dml_plr_boost$predictions$ml_m,D))
colnames(ROA_dml_rmse_m) <- c("RMSE_m")

ROA_DoubleML <- cbind(ROA_dml_sum,ROA_dml_rmse_l,ROA_dml_rmse_m)

#-------------------------------------------------------------------
# 2. Manual Implementation #####
#-------------------------------------------------------------------

## 2.1 Define parameters ####

K <- 3                     # number of folds
B <- 500                   # bootstrap samples
eta <- 0.15
nrounds <- 100

## 2.2 Data preparation ####

x_cols <- colnames(cpx_hd)[5:ncol(cpx_hd)]
n <- nrow(cpx_hd)

Y <- cpx_hd$RD_to_Assets
D <- cpx_hd$ROA
X <- as.matrix(cpx_hd[, x_cols])

# Create folds
set.seed(123)
folds <- createFolds(D, k = K)
theta_vals <- rep(NA, K)

# Store residuals
Y_resid <- rep(NA, n)
D_resid <- rep(NA, n)

## 2.3 Cross-fitting loop ####
set.seed(123)
for (k in 1:K) {
  test_idx <- folds[[k]]
  train_idx <- setdiff(seq_len(n), test_idx)
  
  # Split
  X_train <- X[train_idx, ]
  X_test  <- X[test_idx, ]
  
  D_train <- D[train_idx]
  D_test  <- D[test_idx]
  
  Y_train <- Y[train_idx]
  Y_test  <- Y[test_idx]
  
  # Fit m(x): E[D | X]
  dtrain_d <- xgb.DMatrix(X_train, label = D_train)
  dtest_d <- xgb.DMatrix(X_test)
  
  model_m <- xgboost(data = dtrain_d, objective = "reg:squarederror",
                     eta = eta, nrounds = nrounds, verbose = 0, max_depth= 5)
  
  d_hat <- predict(model_m, dtest_d)
  
  # Fit g(x): E[Y | X]
  dtrain_y <- xgb.DMatrix(X_train, label = Y_train)
  dtest_y <- xgb.DMatrix(X_test)
  
  model_g <- xgboost(data = dtrain_y, objective = "reg:squarederror",
                     eta = eta, nrounds = nrounds, verbose = 0, max_depth= 5)
  
  y_hat <- predict(model_g, dtest_y)
  
  # Save residuals
  Y_resid[test_idx] <- Y_test - y_hat
  D_resid[test_idx] <- D_test - d_hat
}

## 2.3 Performing Bootstrapping ####

# Rename residuals for bootstrap
Ytilde <- Y_resid
Dtilde <- D_resid

## 2.4 Second-stage estimate (no intercept) ####
theta_hat <- coef(lm(Ytilde ~ Dtilde - 1))[1]

## 2.5 Bootstrapping residuals ####
set.seed(123)
boot_estimates <- replicate(B, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))[1]
})

# Bootstrap stats
theta_hat_boot <- mean(boot_estimates)
se_boot <- sd(boot_estimates)
t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

## 2.6 RMSE diagnostics ####
rmse_l <- RMSE(Y, Y - Ytilde)  # g(x)
rmse_m <- RMSE(D, D - Dtilde)  # m(x)

## 2.7 Final results ####
ROA_XGB_DML <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

colnames(ROA_XGB_DML) <- colnames(ROA_DoubleML) 

ROA_DoubleML
ROA_XGB_DML

Results_ROA <- rbind(ROA_DoubleML,ROA_XGB_DML)

rownames(Results_ROA) <- c("DoubleML","Manual")

write.csv(Results_ROA, "e_drafts/results/XGB/A_DML_ROA.csv")
