#########################################################################+
# XGBoost: FD ###########################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list=ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES ####

df <- readRDS("a_microdata/temp/Sample_2.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

## 0.3 creating delta variables ####

# Remove the lag values from 2 to 5
df <- df %>%select(-matches("lag[2-5]"))

# Creating delta versions
## Dependent
df$delta_RD_to_Assets = df$RD_to_Assets - df$RD_to_Assets_lag1
## D
df$delta_ROA = df$ROA-df$ROA_lag1
df$delta_Leverage = df$Leverage-df$Leverage_lag1
df$delta_Market_to_Book = df$Market_to_Book-df$Market_to_Book_lag1

df <- df %>%select(-matches("lag1"))

df <- df %>% 
  select(-c("ROA","Leverage","Market_to_Book","RD_to_Assets")) %>% 
  select(gvkey, fyear, delta_RD_to_Assets,
         delta_ROA,delta_Leverage,delta_Market_to_Book,
         everything())

## 0.4 XGBoost function ####

run_dml_fd <- function(ntrees) {
  cat("Running DML with tuning of depth and eta\n")
  
  # Define parameter grid
  param_grid = list(
    "ml_l" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    ),
    "ml_m" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    )
  )
  
  # Base learner with fixed parameters
  learner <- lrn("regr.xgboost",
                 nrounds = ntrees,
                 lambda = 1,
                 alpha = 0)
  
  # Clone for ml_l and ml_m
  ml_l <- learner$clone()
  ml_m <- learner$clone()
  
  # Create DML object
  dml_plr <- dml_approx_plr$new(dml_data,
                                ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  # Tune depth and eta
  set.seed(123)
  dml_plr$tune(
    param_set = param_grid,
    tune_settings = list(
      terminator = trm("evals", n_evals = 10),  # Fewer evaluations needed
      algorithm = tnr("random_search"),
      rsmp_tune = rsmp("cv", folds = 5),
      measure = list("ml_l" = msr("regr.mse"), "ml_m" = msr("regr.mse"))
    ),
    tune_on_folds = FALSE
  )
  
  dml_plr$fit()
  
  result <- dml_plr$summary()
  print(result)
  beepr::beep(sound = 2)
  gc()
  
  return(list(model = dml_plr, summary = dml_plr$summary()))
}

##############################################################################+
# 1. ROA ######################################################################

## 1.0 Creating the object #####

xvars <- setdiff(names(df), 
                 c("gvkey", "fyear", "delta_ROA", "delta_RD_to_Assets"))

dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                            x_cols = xvars,
                                            y_col = "delta_RD_to_Assets",
                                            d_cols = "delta_ROA",
                                            cluster_cols = "gvkey")

remove(xvars);gc()


## 1.1 300 trees ####

result_1 <- run_dml_fd(ntrees=300)

roa300 <- result_1$model$summary()
roa300_depth_l <- result_1$model$params$ml_l$delta_ROA$max_depth
roa300_eta_l <- result_1$model$params$ml_l$delta_ROA$eta
roa300_depth_m <- result_1$model$params$ml_m$delta_ROA$max_depth
roa300_eta_m <- result_1$model$params$ml_m$delta_ROA$eta

## 1.2 500 trees ####

result_2 <- run_dml_fd(ntrees=500)

roa500 <- result_2$model$summary()
roa500_depth_l <- result_2$model$params$ml_l$delta_ROA$max_depth
roa500_eta_l <- result_2$model$params$ml_l$delta_ROA$eta
roa500_depth_m <- result_2$model$params$ml_m$delta_ROA$max_depth
roa500_eta_m <- result_2$model$params$ml_m$delta_ROA$eta


##############################################################################+
# 2. Leverage #################################################################

## 2.0 Creating the object ####

xvars <- setdiff(names(df), 
                 c("gvkey", "fyear", "delta_Leverage", "delta_RD_to_Assets"))

dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                            x_cols = xvars,
                                            y_col = "delta_RD_to_Assets",
                                            d_cols = "delta_Leverage",
                                            cluster_cols = "gvkey")

remove(xvars);gc()


## 2.1 300 trees ####

result_3 <- run_dml_fd(ntrees=300)

Lev300 <- result_3$model$summary()
Lev300_depth_l <- result_3$model$params$ml_l$delta_Leverage$max_depth
Lev300_eta_l <- result_3$model$params$ml_l$delta_Leverage$eta
Lev300_depth_m <- result_3$model$params$ml_m$delta_Leverage$max_depth
Lev300_eta_m <- result_3$model$params$ml_m$delta_Leverage$eta

## 2.2 500 trees ####

result_4 <- run_dml_fd(ntrees=500)

Lev500 <- result_4$model$summary()
Lev500_depth_l <- result_4$model$params$ml_l$delta_Leverage$max_depth
Lev500_eta_l <- result_4$model$params$ml_l$delta_Leverage$eta
Lev500_depth_m <- result_4$model$params$ml_m$delta_Leverage$max_depth
Lev500_eta_m <- result_4$model$params$ml_m$delta_Leverage$eta

##############################################################################+
# 3. Market to Book ###########################################################

## 3.0 Creating the object ####

xvars <- setdiff(names(df), 
                 c("gvkey", "fyear", "delta_Market_to_Book", "delta_RD_to_Assets"))

dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                            x_cols = xvars,
                                            y_col = "delta_RD_to_Assets",
                                            d_cols = "delta_Market_to_Book",
                                            cluster_cols = "gvkey")

remove(xvars);gc()

## 3.1 300 trees ####

result_5 <- run_dml_fd(ntrees=300)

MtB300 <- result_5$model$summary()
MtB300_depth_l <- result_5$model$params$ml_l$delta_Market_to_Book$max_depth
MtB300_eta_l <- result_5$model$params$ml_l$delta_Market_to_Book$eta
MtB300_depth_m <- result_5$model$params$ml_m$delta_Market_to_Book$max_depth
MtB300_eta_m <- result_5$model$params$ml_m$delta_Market_to_Book$eta

## 3.2 500 trees ####

result_6 <- run_dml_fd(ntrees=500)

MtB500 <- result_6$model$summary()
MtB500_depth_l <- result_6$model$params$ml_l$delta_Market_to_Book$max_depth
MtB500_eta_l <- result_6$model$params$ml_l$delta_Market_to_Book$eta
MtB500_depth_m <- result_6$model$params$ml_m$delta_Market_to_Book$max_depth
MtB500_eta_m <- result_6$model$params$ml_m$delta_Market_to_Book$eta


##############################################################################+
# A. MERGING RESULTS #####################

results <- unname(rbind(roa300,roa500,
                        Lev300,Lev500,
                        MtB300,MtB500))

depth_l <- unname(rbind(roa300_depth_l,roa500_depth_l,
                        Lev300_depth_l,Lev500_depth_l,
                        MtB300_depth_l,MtB500_depth_l))

depth_m <- unname(rbind(roa300_depth_m,roa500_depth_m,
                        Lev300_depth_m,Lev500_depth_m,
                        MtB300_depth_m,MtB500_depth_m))

eta_l <- unname(rbind(roa300_eta_l,roa500_eta_l,
                      Lev300_eta_l,Lev500_eta_l,
                      MtB300_eta_l,MtB500_eta_l))

eta_m <- unname(rbind(roa300_eta_m,roa500_eta_m,
                      Lev300_eta_m,Lev500_eta_m,
                      MtB300_eta_m,MtB500_eta_m))

colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value")
colnames(depth_l) <- c("depth_l")
colnames(eta_l) <- c("eta_l")
colnames(depth_m) <- c("depth_m")
colnames(eta_m) <- c("eta_m")


results_print <- cbind(results, depth_l,eta_l, depth_m,eta_m)


rownames(results_print) <- c("ROA 300","ROA 500",
                             "Leverage 300","Leverage 500",
                             "MtB 300","MtB 500")

write.csv(results_print, "e_drafts/results/XGB/FD_Ind100_0521.csv")