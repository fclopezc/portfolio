#########################################################################+
# LASSO: DML ############################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("dml_data")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)

## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Assigning time ####

K <- 10
years <- sort(unique(df$fyear))
T_total <- length(years)
block_size <- floor(T_total / (K-1))

# Assign years to contiguous blocks
year_blocks <- cut(1:T_total, breaks = K, labels = FALSE)
block_mapping <- data.frame(fyear = years, block = year_blocks)
df <- df %>% left_join(block_mapping, by = "fyear")

remove(list =c("block_size","T_total","years","year_blocks",
               "block_mapping"))


## 0.4 Define quasy complement ####

get_quasi_complement <- function(k, K) {
  if (K < 3) stop("K must be >= 3 for NLO cross-fitting")
  if (k == 1) return(3:K)               # Exclude 1, 2
  if (k == 2) return(4:K)               # Exclude 2, 3
  if (k == K) return(1:(K-2))           # Exclude K-1, K
  if (k == K-1) return(1:(K-3))         # Exclude K-2, K-1
  c(1:(k-2), (k+2):K)                  # General case
}

## 0.5 Lambdas ####

inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)

## 0.6 Common controls ####

Y <- df[,c("RD_to_Assets")]

X <- df[,setdiff(names(df), 
                 c("gvkey", "fyear", "RD_to_Assets","block",
                   "ROA","Leverage","Market_to_Book"))]

controls <- as.matrix(X)

###########################################################+
# 1. ROA ##################################################
###########################################################+

## 1.1 Defining variables #####

D <- df[,c("ROA")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 1.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Outcome model (Y ~ X)
  fit.glmnet.Y <- glmnet(
    x = controls[train, ], 
    y = Y[train],
    family = "gaussian",
    alpha = 1,
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.outcome
  )
  Ytilde[test] <- Y[test] - predict(fit.glmnet.Y, newx = controls[test, ], s = "lambda.min")
  
  # Treatment model (D ~ X)
  fit.glmnet.D <- glmnet(
    x = controls[train, ], 
    y = D[train],
    family = "gaussian",
    alpha = 1,  # LASSO
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.treat
  )
  Dtilde[test] <- D[test] - predict(fit.glmnet.D, newx = controls[test, ], s = "lambda.min")
}

## 1.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
ROA_NLO_Theo <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

###########################################################+
# 2. Leverage ##################################################
###########################################################+

## 2.1 Defining variables #####

D <- df[,c("Leverage")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 2.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Outcome model (Y ~ X)
  fit.glmnet.Y <- glmnet(
    x = controls[train, ], 
    y = Y[train],
    family = "gaussian",
    alpha = 1,
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.outcome
  )
  Ytilde[test] <- Y[test] - predict(fit.glmnet.Y, newx = controls[test, ], s = "lambda.min")
  
  # Treatment model (D ~ X)
  fit.glmnet.D <- glmnet(
    x = controls[train, ], 
    y = D[train],
    family = "gaussian",
    alpha = 1,  # LASSO
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.treat
  )
  Dtilde[test] <- D[test] - predict(fit.glmnet.D, newx = controls[test, ], s = "lambda.min")
}

## 2.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
Lev_NLO_Theo <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

beepr::beep(sound = 2)

###########################################################+
# 3. Market to Book #######################################
###########################################################+

## 3.1 Defining variables #####

D <- df[,c("Market_to_Book")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 3.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Outcome model (Y ~ X)
  fit.glmnet.Y <- glmnet(
    x = controls[train, ], 
    y = Y[train],
    family = "gaussian",
    alpha = 1,
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.outcome
  )
  Ytilde[test] <- Y[test] - predict(fit.glmnet.Y, newx = controls[test, ], s = "lambda.min")
  
  # Treatment model (D ~ X)
  fit.glmnet.D <- glmnet(
    x = controls[train, ], 
    y = D[train],
    family = "gaussian",
    alpha = 1,  # LASSO
    nfolds = 10,
    standardize = TRUE,
    intercept = FALSE, lambda = lambda.treat
  )
  Dtilde[test] <- D[test] - predict(fit.glmnet.D, newx = controls[test, ], s = "lambda.min")
}

## 3.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
MtB_NLO_Theo <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

beepr::beep(sound = 2)

# A. MERGING RESULTS ####

results <- unname(rbind(ROA_NLO_Theo,
                        Lev_NLO_Theo,
                        MtB_NLO_Theo))

colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value",
                       "RMSE_l","RMSE_m")
rownames(results) <- c("ROA_Theo",
                       "Leverage_Thep",
                       "MtB_Theo")


write.csv(results, "e_drafts/results/LASSO/7A_NLO_NoInt_Theo.csv")
