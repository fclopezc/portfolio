#########################################################################+
# LASSO: CRE ############################################################+
## Joint Effect ##########################################################
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("df", "noInt_CRE_Theo","Int_CRE_Theo")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_0.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Parameters for theoretical lambdas
inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)


##############################################################################+
# 1. NO INTERACTIONS ##########################################################

## 1.0 Creating the object #####


exclude_cols <- c("gvkey", "fyear", 
                  "ROA","Leverage","Market_to_Book","RD_to_Assets")

bar_cols <- grep("^bar_", names(df), value = TRUE)
x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))

xbar_cols <- bar_cols[!bar_cols %in% c("bar_ROA", "bar_Leverage", "bar_Market_to_Book",
                                       "bar_RD_to_Assets")]

#setDT(df)

treatments <- names(df[,c("ROA","Leverage","Market_to_Book")])
bar_treatments <- names(df[,c("bar_ROA","bar_Leverage","bar_Market_to_Book")])


# Initialize list to store results for each treatment
dml_vector <- list()

# Loop over treatments
for (i in seq_along(treatments)) {
  d <- treatments[i]
  d_bar <- bar_treatments[i]
  
  dml_data <- dml_cre_data_from_data_frame(
    data.table::as.data.table(df),
    x_cols = x_cols,
    y_col = "RD_to_Assets",
    d_cols = d,
    xbar_cols = xbar_cols,
    dbar_cols = d_bar,
    cluster_cols = "gvkey"
  )
  
  
  dml_vector[[d]] <- dml_data
}

remove(bar_cols);remove(exclude_cols);remove(x_cols);remove(xbar_cols)

gc()

## 1.1 Theorical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )

# Container to store fitted models and summaries
dml_fits <- list()
dml_summaries <- list()

# Loop over treatment variables
for (d in names(dml_vector)) {
  
  dml_model <- dml_cre_plr$new(
    dml_vector[[d]],
    ml_l = ml_l,
    ml_m = ml_m,
    score = "orth-PO",
    dml_procedure = "dml2",
    dml_approach = "cre",
    n_folds = 10
  )
  
  dml_model$fit(store_predictions = TRUE)
  
  dml_fits[[d]] <- dml_model
  dml_summaries[[d]] <- dml_model$summary()
}

summary <- rbind(dml_summaries$ROA,
                        dml_summaries$Leverage,
                        dml_summaries$Market_to_Book)

rmse_l <- rbind(dml_fits$ROA$rmses$ml_l,
                           dml_fits$ROA$rmses$ml_l,
                           dml_fits$ROA$rmses$ml_l)
colnames(rmse_l) <- c("RMSE_l")

rmse_m <- rbind(dml_fits$ROA$rmses$ml_m,
                             dml_fits$ROA$rmses$ml_m,
                             dml_fits$ROA$rmses$ml_m)
colnames(rmse_m) <- c("RMSE_m")


rmse <- rbind(dml_fits$ROA$model_rmse,
                           dml_fits$Leverage$model_rmse,
                           dml_fits$Market_to_Book$model_rmse)
colnames(rmse) <- c("RMSE")

noInt_CRE_Theo <- cbind(summary,rmse_l,
                        rmse_m,rmse)

beepr::beep(sound = 2); gc()

## 1.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)


# Container to store fitted models and summaries
dml_fits <- list()
dml_summaries <- list()

# Loop over treatment variables
for (d in names(dml_vector)) {
  
  dml_model <- dml_cre_plr$new(
    dml_vector[[d]],
    ml_l = ml_l,
    ml_m = ml_m,
    score = "orth-PO",
    dml_procedure = "dml2",
    dml_approach = "cre",
    n_folds = 10
  )
  
  dml_model$fit()
  
  dml_fits[[d]] <- dml_model
  dml_summaries[[d]] <- dml_model$summary()
}

summary <- rbind(dml_summaries$ROA,
                 dml_summaries$Leverage,
                 dml_summaries$Market_to_Book)

rmse_l <- rbind(dml_fits$ROA$rmses$ml_l,
                dml_fits$ROA$rmses$ml_l,
                dml_fits$ROA$rmses$ml_l)
colnames(rmse_l) <- c("RMSE_l")

rmse_m <- rbind(dml_fits$ROA$rmses$ml_m,
                dml_fits$ROA$rmses$ml_m,
                dml_fits$ROA$rmses$ml_m)
colnames(rmse_m) <- c("RMSE_m")


rmse <- rbind(dml_fits$ROA$model_rmse,
              dml_fits$Leverage$model_rmse,
              dml_fits$Market_to_Book$model_rmse)
colnames(rmse) <- c("RMSE")

noInt_CRE_CV <- cbind(summary,rmse_l,
                        rmse_m,rmse)

beepr::beep(sound = 2); gc()

##############################################################################+
# 2. INTERACTIONS #############################################################

## 2.0 Creating the object #####

exclude_cols <- c("gvkey", "fyear", 
                  "ROA","Leverage","Market_to_Book","RD_to_Assets",
                  "ROA.Leverage","ROA.Market_to_Book","Leverage.Market_to_Book")

bar_cols <- grep("^bar_", names(df), value = TRUE)
x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))

xbar_cols <- bar_cols[!bar_cols %in% c("bar_ROA", "bar_Leverage", "bar_Market_to_Book",
                                       "bar_RD_to_Assets",
                                       "bar_ROA.Leverage",
                                       "bar_ROA.Market_to_Book",
                                       "bar_Leverage.Market_to_Book")]

#setDT(df)

treatments <- names(df[,c("ROA","Leverage","Market_to_Book",
                          "ROA.Leverage","ROA.Market_to_Book","Leverage.Market_to_Book")])
bar_treatments <- names(df[,c("bar_ROA","bar_Leverage","bar_Market_to_Book",
                              "bar_ROA.Leverage",
                              "bar_ROA.Market_to_Book",
                              "bar_Leverage.Market_to_Book")])

# Initialize list to store results for each treatment
dml_vector <- list()

# Loop over treatments
for (i in seq_along(treatments)) {
  d <- treatments[i]
  d_bar <- bar_treatments[i]
  
  dml_data <- dml_cre_data_from_data_frame(
    data.table::as.data.table(df),
    x_cols = x_cols,
    y_col = "RD_to_Assets",
    d_cols = d,
    xbar_cols = xbar_cols,
    dbar_cols = d_bar,
    cluster_cols = "gvkey"
  )
  
  
  dml_vector[[d]] <- dml_data
}

remove(bar_cols);remove(exclude_cols);remove(x_cols);remove(xbar_cols)

gc()

## 2.1 Theorical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )

# Container to store fitted models and summaries
dml_fits <- list()
dml_summaries <- list()

# Loop over treatment variables
for (d in names(dml_vector)) {
  
  dml_model <- dml_cre_plr$new(
    dml_vector[[d]],
    ml_l = ml_l,
    ml_m = ml_m,
    score = "orth-PO",
    dml_procedure = "dml2",
    dml_approach = "cre",
    n_folds = 10
  )
  
  dml_model$fit(store_predictions = TRUE)
  
  dml_fits[[d]] <- dml_model
  dml_summaries[[d]] <- dml_model$summary()
}

summary <- rbind(dml_summaries$ROA,
                 dml_summaries$Leverage,
                 dml_summaries$Market_to_Book,
                 dml_summaries$ROA.Leverage,
                 dml_summaries$ROA.Market_to_Book,
                 dml_summaries$Leverage.Market_to_Book)

rmse_l <- rbind(dml_fits$ROA$rmses$ml_l,
                dml_fits$Leverage$rmses$ml_l,
                dml_fits$Market_to_Book$rmses$ml_l,
                dml_fits$ROA.Leverage$rmses$ml_l,
                dml_fits$ROA.Market_to_Book$rmses$ml_l,
                dml_fits$Leverage.Market_to_Book$rmses$ml_l)
colnames(rmse_l) <- c("RMSE_l")

rmse_m <- rbind(dml_fits$ROA$rmses$ml_m,
                dml_fits$Leverage$rmses$ml_m,
                dml_fits$Market_to_Book$rmses$ml_m,
                dml_fits$ROA.Leverage$rmses$ml_m,
                dml_fits$ROA.Market_to_Book$rmses$ml_m,
                dml_fits$Leverage.Market_to_Book$rmses$ml_m)
colnames(rmse_m) <- c("RMSE_m")


rmse <- rbind(dml_fits$ROA$model_rmse,
              dml_fits$Leverage$model_rmse,
              dml_fits$Market_to_Book$model_rmse,
              dml_fits$ROA.Leverage$model_rmse,
              dml_fits$ROA.Market_to_Book$model_rmse,
              dml_fits$Leverage.Market_to_Book$model_rmse)
colnames(rmse) <- c("RMSE")

Int_CRE_Theo <- cbind(summary,rmse_l,
                    rmse_m,rmse)

beepr::beep(sound = 2); gc()

## 2.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)


# Container to store fitted models and summaries
dml_fits <- list()
dml_summaries <- list()

# Loop over treatment variables
for (d in names(dml_vector)) {
  
  dml_model <- dml_cre_plr$new(
    dml_vector[[d]],
    ml_l = ml_l,
    ml_m = ml_m,
    score = "orth-PO",
    dml_procedure = "dml2",
    dml_approach = "cre",
    n_folds = 10
  )
  
  dml_model$fit()
  
  dml_fits[[d]] <- dml_model
  dml_summaries[[d]] <- dml_model$summary()
}

summary <- rbind(dml_summaries$ROA,
                 dml_summaries$Leverage,
                 dml_summaries$Market_to_Book,
                 dml_summaries$ROA.Leverage,
                 dml_summaries$ROA.Market_to_Book,
                 dml_summaries$Leverage.Market_to_Book)

rmse_l <- rbind(dml_fits$ROA$rmses$ml_l,
                dml_fits$Leverage$rmses$ml_l,
                dml_fits$Market_to_Book$rmses$ml_l,
                dml_fits$ROA.Leverage$rmses$ml_l,
                dml_fits$ROA.Market_to_Book$rmses$ml_l,
                dml_fits$Leverage.Market_to_Book$rmses$ml_l)
colnames(rmse_l) <- c("RMSE_l")

rmse_m <- rbind(dml_fits$ROA$rmses$ml_m,
                dml_fits$Leverage$rmses$ml_m,
                dml_fits$Market_to_Book$rmses$ml_m,
                dml_fits$ROA.Leverage$rmses$ml_m,
                dml_fits$ROA.Market_to_Book$rmses$ml_m,
                dml_fits$Leverage.Market_to_Book$rmses$ml_m)
colnames(rmse_m) <- c("RMSE_m")


rmse <- rbind(dml_fits$ROA$model_rmse,
              dml_fits$Leverage$model_rmse,
              dml_fits$Market_to_Book$model_rmse,
              dml_fits$ROA.Leverage$model_rmse,
              dml_fits$ROA.Market_to_Book$model_rmse,
              dml_fits$Leverage.Market_to_Book$model_rmse)
colnames(rmse) <- c("RMSE")

Int_CRE_CV <- cbind(summary,rmse_l,
                      rmse_m,rmse)

beepr::beep(sound = 2); gc()