#########################################################################
# LASSO: CRE - Simplified Version #######################################
#########################################################################

# Clean up and setup
cat("\014")
rm(list = ls())
gc()
future::plan("multisession", workers = availableCores() - 1)

# Load libraries and data
source("c_code/0_Libraries.R")

df <- readRDS("a_microdata/temp/Sample_0.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

# Parameters
n_obs <- nrow(df)
lambda.treat <- 2*(log(n_obs))^(3/2)/sqrt(n_obs)
lambda.outcome <- 0.05*(log(n_obs))^(3/2)/sqrt(n_obs)

# Helper function to run DML analysis
run_dml_analysis <- function(df, treatments, bar_treatments, x_cols, xbar_cols, 
                             lambda_type = "theoretical", n_folds = 10) {
  
  # Set up learners based on lambda type
  if (lambda_type == "theoretical") {
    ml_l <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, lambda = lambda.outcome)
    ml_m <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, lambda = lambda.treat)
  } else {
    ml_l <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, s = "lambda.min", nfolds = n_folds)
    ml_m <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, s = "lambda.min", nfolds = n_folds)
  }
  
  # Initialize storage
  dml_fits <- list()
  dml_summaries <- list()
  rmses_l <- list()
  rmses_m <- list()
  model_rmses <- list()
  
  # Process each treatment
  for (i in seq_along(treatments)) {
    d <- treatments[i]
    d_bar <- bar_treatments[i]
    
    dml_data <- dml_cre_data_from_data_frame(
      data.table::as.data.table(df),
      x_cols = x_cols,
      y_col = "RD_to_Assets",
      d_cols = d,
      xbar_cols = xbar_cols,
      dbar_cols = d_bar,
      cluster_cols = "gvkey"
    )
    
    dml_model <- dml_cre_plr$new(
      dml_data,
      ml_l = ml_l,
      ml_m = ml_m,
      score = "orth-PO",
      dml_procedure = "dml2",
      dml_approach = "cre",
      n_folds = n_folds
    )
    
    store_preds <- lambda_type == "theoretical"
    dml_model$fit(store_predictions = store_preds)
    
    dml_fits[[d]] <- dml_model
    dml_summaries[[d]] <- dml_model$summary()
    rmses_l[[d]] <- dml_model$rmses$ml_l
    rmses_m[[d]] <- dml_model$rmses$ml_m
    model_rmses[[d]] <- dml_model$model_rmse
  }
  
  # Combine results
  summary_df <- do.call(rbind, dml_summaries)
  rmse_l_df <- matrix(unlist(rmses_l), ncol = 1, dimnames = list(names(rmses_l), "RMSE_l"))
  rmse_m_df <- matrix(unlist(rmses_m), ncol = 1, dimnames = list(names(rmses_m), "RMSE_m"))
  rmse_df <- matrix(unlist(model_rmses), ncol = 1, dimnames = list(names(model_rmses), "RMSE"))
  
  cbind(summary_df, rmse_l_df, rmse_m_df, rmse_df)
}

set.seed(123)

# 1. NO INTERACTIONS ANALYSIS
exclude_cols_no_int <- c("gvkey", "fyear", "ROA", "Leverage", "Market_to_Book", "RD_to_Assets")
bar_cols_no_int <- grep("^bar_", names(df), value = TRUE)
x_cols_no_int <- setdiff(names(df), c(exclude_cols_no_int, bar_cols_no_int))
xbar_cols_no_int <- bar_cols_no_int[!bar_cols_no_int %in% c("bar_ROA", "bar_Leverage", 
                                                            "bar_Market_to_Book", "bar_RD_to_Assets")]

treatments_no_int <- c("ROA", "Leverage", "Market_to_Book")
bar_treatments_no_int <- c("bar_ROA", "bar_Leverage", "bar_Market_to_Book")

# Run analyses
noInt_CRE_Theo2 <- run_dml_analysis(df, treatments_no_int, bar_treatments_no_int, 
                                   x_cols_no_int, xbar_cols_no_int, "theoretical")
set.seed(123)
noInt_CRE_CV <- run_dml_analysis(df, treatments_no_int, bar_treatments_no_int, 
                                 x_cols_no_int, xbar_cols_no_int, "cv")
gc()

# 2. WITH INTERACTIONS ANALYSIS
exclude_cols_int <- c(exclude_cols_no_int, 
                      "ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
bar_cols_int <- grep("^bar_", names(df), value = TRUE)
x_cols_int <- setdiff(names(df), c(exclude_cols_int, bar_cols_int))
xbar_cols_int <- bar_cols_int[!bar_cols_int %in% 
                                c("bar_ROA", "bar_Leverage", "bar_Market_to_Book",
                                  "bar_RD_to_Assets", "bar_ROA.Leverage",
                                  "bar_ROA.Market_to_Book", "bar_Leverage.Market_to_Book")]

treatments_int <- c(treatments_no_int, 
                    "ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
bar_treatments_int <- c(bar_treatments_no_int,
                        "bar_ROA.Leverage", "bar_ROA.Market_to_Book", 
                        "bar_Leverage.Market_to_Book")

# Run analyses
set.seed(123)
Int_CRE_Theo <- run_dml_analysis(df, treatments_int, bar_treatments_int, 
                                 x_cols_int, xbar_cols_int, "theoretical")

set.seed(123)
Int_CRE_CV <- run_dml_analysis(df, treatments_int, bar_treatments_int, 
                               x_cols_int, xbar_cols_int, "cv")
gc()

# Clean up and notify
beepr::beep(sound = 2)
gc()

# A. Merging results ###########################################

results <- rbind(noInt_CRE_Theo,noInt_CRE_CV,Int_CRE_Theo,Int_CRE_CV)

rownames(results) <- c("No_Int_Theo_ROA","No_Int_Theo_Leverage","No_Int_Theo_MtB",
                       "No_Int_CV_ROA","No_Int_CV_Leverage","No_CV_Theo_MtB",
                       "Int_Theo_ROA","Int_Theo_Leverage","Int_Theo_MtB",
                       "Int_Theo_ROA^Leverage","Int_Theo_ROA^MtB","Int_Theo_Leverage^MtB",
                       "Int_CV_ROA","Int_CV_Leverage","Int_CV_MtB",
                       "Int_CV_ROA^Leverage","Int_CV_ROA^MtB","Int_CV_Leverage^MtB")

write.csv(results, "e_drafts/results/LASSO/6_CRE_joint.csv")
