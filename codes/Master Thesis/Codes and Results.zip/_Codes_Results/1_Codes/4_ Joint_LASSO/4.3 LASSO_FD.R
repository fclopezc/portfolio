#########################################################################
# LASSO: FD - Joint Effects Version ####################################
#########################################################################

# Clean up and setup
cat("\014")
rm(list = ls())
gc()
future::plan("multisession", workers = availableCores() - 1)

# Load libraries and data
source("c_code/0_Libraries.R")

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the data still balanced

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy
df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

# Creating delta versions
## Dependent
df$delta_RD_to_Assets = df$RD_to_Assets - df$RD_to_Assets_lag1
## D variables
df$delta_ROA = df$ROA - df$ROA_lag1
df$delta_Leverage = df$Leverage - df$Leverage_lag1
df$delta_Market_to_Book = df$Market_to_Book - df$Market_to_Book_lag1
df$delta_ROA.Leverage = df$ROA.Leverage - df$ROA.Leverage_lag1
df$delta_ROA.Market_to_Book = df$ROA.Market_to_Book - df$ROA.Market_to_Book_lag1
df$delta_Leverage.Market_to_Book = df$Leverage.Market_to_Book - df$Leverage.Market_to_Book_lag1

# Remove lag variables and original variables
df <- df %>% select(-matches("lag[1-5]"))
df <- df %>% select(-c("ROA", "Leverage", "Market_to_Book", "RD_to_Assets")) %>% 
  select(gvkey, fyear, delta_RD_to_Assets,
         delta_ROA, delta_Leverage, delta_Market_to_Book,
         delta_ROA.Leverage, delta_ROA.Market_to_Book, delta_Leverage.Market_to_Book,
         everything())

# Parameters
n_obs <- nrow(df)
lambda.treat <- 2*(log(n_obs))^(3/2)/sqrt(n_obs)
lambda.outcome <- 0.05*(log(n_obs))^(3/2)/sqrt(n_obs)

# Helper function to run FD DML analysis
run_fd_dml_analysis <- function(df, treatments, lambda_type = "theoretical", n_folds = 10) {
  
  # Set up learners based on lambda type
  if (lambda_type == "theoretical") {
    ml_l <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, lambda = lambda.outcome)
    ml_m <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, lambda = lambda.treat)
  } else {
    ml_l <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, s = "lambda.min", nfolds = n_folds)
    ml_m <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE, 
                intercept = FALSE, s = "lambda.min", nfolds = n_folds)
  }
  
  # Initialize storage
  dml_fits <- list()
  dml_summaries <- list()
  rmses_l <- list()
  rmses_m <- list()
  model_rmses <- list()
  
  # Process each treatment combination
  for (i in seq_along(treatments)) {
    treatment_combo <- treatments[[i]]
    
    # Create formula for interaction terms if needed
    if (length(treatment_combo) > 1) {
      # Create interaction term
      int_term <- paste(treatment_combo, collapse = "*")
      df[[int_term]] <- apply(df[, treatment_combo], 1, prod)
      
      # Update treatment column to be the interaction term
      d_col <- int_term
    } else {
      d_col <- treatment_combo
    }
    
    # Prepare x variables (excluding treatment variables)
    xvars <- setdiff(names(df), 
                     c("gvkey", "fyear", "delta_RD_to_Assets", treatment_combo))
    
    dml_data <- dml_approx_data_from_data_frame(
      data.table::as.data.table(df),
      x_cols = xvars,
      y_col = "delta_RD_to_Assets",
      d_cols = d_col,
      cluster_cols = "gvkey"
    )
    
    dml_model <- dml_approx_plr$new(
      dml_data,
      ml_l = ml_l,
      ml_m = ml_m,
      n_folds = n_folds
    )
    
    store_preds <- lambda_type == "theoretical"
    dml_model$fit(store_predictions = store_preds)
    
    # Store results with appropriate names
    model_name <- ifelse(length(treatment_combo) > 1, 
                         paste(treatment_combo, collapse = "_"), 
                         treatment_combo)
    
    dml_fits[[model_name]] <- dml_model
    dml_summaries[[model_name]] <- dml_model$summary()
    rmses_l[[model_name]] <- dml_model$rmses$ml_l
    rmses_m[[model_name]] <- dml_model$rmses$ml_m
    model_rmses[[model_name]] <- dml_model$model_rmse
    
    # Remove interaction term if we created one
    if (length(treatment_combo) > 1) {
      df <- df %>% select(-all_of(d_col))
    }
  }
  
  # Combine results
  summary_df <- do.call(rbind, dml_summaries)
  rmse_l_df <- matrix(unlist(rmses_l), ncol = 1, dimnames = list(names(rmses_l), "RMSE_l"))
  rmse_m_df <- matrix(unlist(rmses_m), ncol = 1, dimnames = list(names(rmses_m), "RMSE_m"))
  rmse_df <- matrix(unlist(model_rmses), ncol = 1, dimnames = list(names(model_rmses), "RMSE"))
  
  cbind(summary_df, rmse_l_df, rmse_m_df, rmse_df)
}

set.seed(123)

# 1. INDIVIDUAL EFFECTS ANALYSIS ###
treatments_individual <- list("delta_ROA", "delta_Leverage", "delta_Market_to_Book")

# Run analyses
set.seed(123)
Indiv_FD_Theo <- run_fd_dml_analysis(df, treatments_individual, "theoretical")
set.seed(123)
Indiv_FD_CV <- run_fd_dml_analysis(df, treatments_individual, "cv")
gc()

# 2. PAIRWISE INTERACTION EFFECTS ANALYSIS ####
treatments_interactions <- list(
  "delta_ROA",
  "delta_Leverage",
  "delta_Market_to_Book",
  "delta_ROA.Leverage",
  "delta_ROA.Market_to_Book",
  "delta_Leverage.Market_to_Book")

# Run analyses
set.seed(123)
Inter_FD_Theo <- run_fd_dml_analysis(df, treatments_interactions, "theoretical")
set.seed(123)
Inter_FD_CV <- run_fd_dml_analysis(df, treatments_interactions, "cv")
gc()

# Clean up and notify
beepr::beep(sound = 2)
gc()

# A. Merging results ###########################################
results <- rbind(Indiv_FD_Theo, Indiv_FD_CV, 
                 Inter_FD_Theo, Inter_FD_CV)

# Create meaningful row names
rownames(results) <- c(
  "Indiv_Theo_ROA", "Indiv_Theo_Leverage", "Indiv_Theo_MtB",
  "Indiv_CV_ROA", "Indiv_CV_Leverage", "Indiv_CV_MtB",
  "Inter_Theo_ROA", "Inter_Theo_Leverage", "Inter_Theo_MtB",
  "Inter_Theo_ROA_Leverage", "Inter_Theo_ROA_MtB", "Inter_Theo_Leverage_MtB",
  "Inter_CV_ROA", "Inter_CV_Leverage", "Inter_CV_MtB",
  "Inter_CV_ROA_Leverage", "Inter_CV_ROA_MtB", "Inter_CV_Leverage_MtB")

write.csv(results, "e_drafts/results/LASSO/7_FD_Joint.csv")
