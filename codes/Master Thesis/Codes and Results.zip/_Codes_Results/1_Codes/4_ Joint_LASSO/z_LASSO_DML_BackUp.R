#########################################################################+
# LASSO: DML ############################################################+
## Joint Effect #########################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
#rm(list = setdiff(ls(),c("df", "No_Int_Theo","No_Int_CV",
#                         "Int_Theo","Int_CV")))
rm(list = ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Parameters for theoretical lambdas
inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)

##############################################################################+
# 1. No Interactions ##########################################################

## 1.0 Creating the object #####

treatments <- names(df[,c("ROA","Leverage","Market_to_Book")])

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = treatments,
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "RD_to_Assets",
                     "ROA","Leverage","Market_to_Book")))

## 1.1 Theorical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )
dml_plr_lasso_theorical = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions = TRUE)

## RMSE
rmse_y <- RMSE(dml_plr_lasso_theorical$predictions$ml_l, df$RD_to_Assets)

rmse_y_rep <- rep(rmse_y, length(treatments))

# Treatment models RMSEs (d)
d_actual <- df[, treatments]
d_pred <- as.data.frame(dml_plr_lasso_theorical$predictions$ml_m)

rmse_d <- sapply(seq_along(treatments), function(i) {
  RMSE(d_pred[[i]], d_actual[[i]])
})
names(rmse_d) <- treatments

rmse_d <- as.data.frame(rmse_d)

## Summary 

stats_result <- dml_plr_lasso_theorical$summary()

## Merging

No_Int_Theo <- cbind(stats_result, rmse_y_rep, rmse_d)


beepr::beep(sound = 2); gc()

## 1.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)
dml_plr_lasso_cv = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
dml_plr_lasso_cv$fit(store_predictions = TRUE)
NoInt_DML_CV <- dml_plr_lasso_cv$summary()

beepr::beep(sound = 2); gc()

##############################################################################+
# 2. With Interactions #######################################################

## 2.0 Creating the object #####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = c("ROA","Leverage","Market_to_Book",
             "ROA.Leverage","ROA.Market_to_Book","Leverage.Market_to_Book"),
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "RD_to_Assets",
                     "ROA","Leverage","Market_to_Book",
                     "ROA.Leverage","ROA.Market_to_Book","Leverage.Market_to_Book")))

## 2.1 Theorical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )
dml_plr_lasso_theorical = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions = TRUE)

Int_DML_Theo <- dml_plr_lasso_theorical$summary()

beepr::beep(sound = 2); gc()

## 2.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)
dml_plr_lasso_cv = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
dml_plr_lasso_cv$fit(store_predictions = TRUE)
Int_DML_CV <- dml_plr_lasso_cv$summary()

beepr::beep(sound = 2); gc()


##############################################################################+
# A. MERGE RESULTS ############################################################

results <- unname(rbind(NoInt_DML_Theo,NoInt_DML_CV,
                        Int_DML_Theo,Int_DML_CV))

colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value")
rownames(results) <- c("No_Int_Theo_ROA","No_Int_Theo_Leverage","No_Int_Theo_MtB",
                       "No_Int_CV_ROA","No_Int_CV_Leverage","No_CV_Theo_MtB",
                       "Int_Theo_ROA","Int_Theo_Leverage","Int_Theo_MtB",
                       "Int_Theo_ROA^Leverage","Int_Theo_ROA^MtB","Int_Theo_Leverage^MtB",
                       "Int_CV_ROA","Int_CV_Leverage","Int_CV_MtB",
                       "Int_CV_ROA^Leverage","Int_CV_ROA^MtB","Int_CV_Leverage^MtB")

results_formatted <- data.frame(
  Estimate = sprintf("%.4f", results[,1]),
  Std.Error = sprintf("%.4f", results[,2]),
  t.value = sprintf("%.4f", results[,3]),
  p.value = formatC(results[,4], format = "e", digits = 2)
)
rownames(results_formatted) <- rownames(results)

write.csv(results_formatted, "e_drafts/results/LASSO/DML_Joint_0518.csv")