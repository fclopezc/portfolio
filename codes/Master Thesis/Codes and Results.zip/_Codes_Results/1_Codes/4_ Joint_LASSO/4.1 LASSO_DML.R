################################################################################
# LASSO-DML: Joint Treatment Effects (with and without interactions) ###########
################################################################################

# CLEAN ENVIRONMENT -----------------------------------------------------------
cat("\014"); rm(list = ls()); gc()

# 0. SETUP ---------------------------------------------------------------------

## Libraries and parallelism
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)

## Load data
df <- readRDS("a_microdata/temp/Sample_1.rds")
stopifnot(plm::is.pbalanced(df))

## Drop unused outcomes, dummy-code `sic`
df <- df %>%
  select(-matches("RD_to_Sales|Log_RD")) %>%
  mutate(across(where(is.character), as.factor)) # ensure `sic` is a factor if needed

df <- cbind(df %>% select(-sic),
            model.matrix(~ sic - 1, data = df))

# 1. PARAMETERS ----------------------------------------------------------------

treatments <- c("ROA", "Leverage", "Market_to_Book")
interactions <- c("ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
y_var <- "RD_to_Assets"

n <- nrow(df)
lambda.treat <- 2 * (log(n))^(3/2) / sqrt(n)
lambda.outcome <- 0.05 * (log(n))^(3/2) / sqrt(n)

# 2. HELPER FUNCTION -----------------------------------------------------------

run_dml <- function(data, d_cols, x_cols, learner_l, learner_m, store_preds = TRUE) {
  dml_data <- DoubleMLData$new(data.table::as.data.table(data),
                               y_col = y_var,
                               d_cols = d_cols,
                               x_cols = x_cols)
  
  dml <- DoubleMLPLR$new(dml_data, learner_l, learner_m, n_folds = 10)
  dml$fit(store_predictions = store_preds)
  
  # Compute RMSEs
  d_actual <- data[, d_cols]
  d_pred <- as.data.frame(dml$predictions$ml_m)
  
  rmse_m <- sapply(seq_along(d_cols), function(i) {
    RMSE(d_pred[[i]], d_actual[[i]])
  })
  
  rmse_y_rep <- rep(RMSE(dml$predictions$ml_l, data[[y_var]]), length(d_cols))
  
  # Combine results
  results <- cbind(dml$summary(), rmse_y = rmse_y_rep, rmse_m = rmse_m)
  return(results)
}

# 3. EXPERIMENTS ---------------------------------------------------------------

## ========== NO INTERACTIONS ==========

x_base <- setdiff(names(df), c("gvkey", "fyear", y_var, treatments))

# 3.1 Theoretical Lambda
ml_l_theo <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE,
                 intercept = FALSE, lambda = lambda.outcome)
ml_m_theo <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE,
                 intercept = FALSE, lambda = lambda.treat)

NoInt_Theo <- run_dml(df, treatments, x_base, ml_l_theo, ml_m_theo)
beepr::beep(2); gc()

# 3.2 Cross-Validation
ml_l_cv <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE,
               intercept = FALSE, s = "lambda.min", nfolds = 10)
ml_m_cv <- lrn("regr.cv_glmnet", family = "gaussian", standardize = TRUE,
               intercept = FALSE, s = "lambda.min", nfolds = 10)

NoInt_CV <- run_dml(df, treatments, x_base, ml_l_cv, ml_m_cv)
beepr::beep(2); gc()

## ========== WITH INTERACTIONS ==========

# Include interaction terms
treatments_inter <- c(treatments, interactions)
x_inter <- setdiff(names(df), c("gvkey", "fyear", y_var, treatments_inter))

# 3.3 Theoretical Lambda
Int_Theo <- run_dml(df, treatments_inter, x_inter, ml_l_theo, ml_m_theo)
beepr::beep(2); gc()

# 3.4 Cross-Validation
Int_CV <- run_dml(df, treatments_inter, x_inter, ml_l_cv, ml_m_cv)
beepr::beep(2); gc()

# 3. MRGERGE RESULTS -----------------------------------------------------------

results <- rbind(NoInt_Theo, NoInt_CV, Int_Theo, Int_CV)

rownames(results) <- c("No_Int_Theo_ROA","No_Int_Theo_Leverage","No_Int_Theo_MtB",
                       "No_Int_CV_ROA","No_Int_CV_Leverage","No_CV_Theo_MtB",
                       "Int_Theo_ROA","Int_Theo_Leverage","Int_Theo_MtB",
                       "Int_Theo_ROA^Leverage","Int_Theo_ROA^MtB","Int_Theo_Leverage^MtB",
                       "Int_CV_ROA","Int_CV_Leverage","Int_CV_MtB",
                       "Int_CV_ROA^Leverage","Int_CV_ROA^MtB","Int_CV_Leverage^MtB")

write.csv(results, "e_drafts/results/LASSO/5_DML_joint.csv")

# saveRDS(list(NoInt_Theo, NoInt_CV, Int_Theo, Int_CV), "results/dml_lasso_summary.rds")
