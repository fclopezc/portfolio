#########################################################################+
# XGBoost: DML ##########################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list=ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_2.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

## 0.3 XGBoost function ####

run_dml <- function(ntrees) {
  cat("Running DML with tuning of depth and eta\n")
  
  # Define parameter grid
  param_grid = list(
    "ml_l" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    ),
    "ml_m" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    )
  )
  
  # Base learner with fixed parameters
  #learner <- lrn("regr.xgboost",nrounds = ntrees,lambda = 1,alpha = 0)
  
  learner <- lrn("regr.xgboost",
                 nrounds = ntrees,
                 early_stopping_rounds = 10,
                 validate = 0.1,
                 lambda = 1,
                 alpha = 0)
  
  # Clone for ml_l and ml_m
  ml_l <- learner$clone()
  ml_m <- learner$clone()
  
  # Create DML object
  dml_plr <- DoubleMLPLR$new(data = dml_data, ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  # Tune depth and eta
  set.seed(123)
  dml_plr$tune(
    param_set = param_grid,
    tune_settings = list(
      terminator = trm("evals", n_evals = 10),
      algorithm = tnr("random_search"),
      rsmp_tune = rsmp("cv", folds = 10),
      measure = list("ml_l" = msr("regr.mse"), "ml_m" = msr("regr.mse"))
    ),
    tune_on_folds = FALSE
  )
  
  dml_plr$fit(store_predictions = TRUE)
  
  # Get standard summary
  result_summary <- dml_plr$summary()
  
  # Get tuned parameters
  params_l <- dml_plr$params$ml_l[[dml_plr$data$d_cols]]
  params_m <- dml_plr$params$ml_m[[dml_plr$data$d_cols]]
  
  # Calculate RMSE for nuisance functions
  preds_l <- dml_plr$predictions$ml_l
  preds_m <- dml_plr$predictions$ml_m
  y <- dml_plr$data$data[[dml_plr$data$y_col]]
  d <- dml_plr$data$data[[dml_plr$data$d_cols]]
  
  # RMSE for ml_l (E[Y|X])
  ##rmse_l <- sqrt(mean((y - preds_l)^2))
  rmse_l <- RMSE(preds_l,y)
  # RMSE for ml_m (E[D|X])
  ##rmse_m <- sqrt(mean((d - preds_m)^2))
  rmse_m <- RMSE(preds_m,d)
  
  # Create enhanced summary
  enhanced_summary <- data.frame(
    Estimate = result_summary[1, 1],
    Std.Error = result_summary[1, 2],
    t.value = result_summary[1, 3],
    p.value = result_summary[1, 4],
    depth_l = params_l$max_depth,
    eta_l = params_l$eta,
    rmse_l = rmse_l,
    depth_m = params_m$max_depth,
    eta_m = params_m$eta,
    rmse_m = rmse_m
  )
  
  print(enhanced_summary)
  beepr::beep(sound = 2)
  gc()
  
  #return(list(model = dml_plr, summary = enhanced_summary))
  return(summary = enhanced_summary)
}


##############################################################################+
# 1. ROA ######################################################################

## 1.0 Creating the object #####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "ROA_lag5",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "ROA_lag5", "RD_to_Assets"))
)

## 1.1 100 trees ####

result_1 <- run_dml(ntrees=100)
rownames(result_1) <-  c("ROA_100")

## 1.2 300 trees ####

result_2 <- run_dml(ntrees=300)
rownames(result_2) <-  c("ROA_300")

## 1.3 500 trees ####

result_3 <- run_dml(ntrees=500)
rownames(result_3) <-  c("ROA_500")

## 1.4 Merge results #####

results_ROA <- rbind(result_1,result_2,result_3)


##############################################################################+
# 2. Leverage #################################################################

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "Leverage_lag5",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "Leverage_lag5", "RD_to_Assets")))


## 2.1 100 trees ####

result_1 <- run_dml(ntrees=100)
rownames(result_1) <-  c("Leverage_100")

## 2.2 300 trees ####

result_2 <- run_dml(ntrees=300)
rownames(result_2) <-  c("Leverage_300")

## 2.3 500 trees ####

result_3 <- run_dml(ntrees=500)
rownames(result_3) <-  c("Leverage_500")

## 2.4 Merge results #####

results_Leverage <- rbind(result_1,result_2,result_3)

##############################################################################+
# 3. Market to Book ###########################################################

## 3.0 Creating the object ####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "Market_to_Book_lag5",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "Market_to_Book_lag5", "RD_to_Assets")))

## 3.1 100 trees ####

result_1 <- run_dml(ntrees=100)
rownames(result_1) <-  c("MtB_100")

## 3.2 300 trees ####

result_2 <- run_dml(ntrees=300)
rownames(result_2) <-  c("MtB_300")

## 3.3 500 trees ####

result_3 <- run_dml(ntrees=500)
rownames(result_3) <-  c("MtB_500")

## 3.4 Merge results #####

results_MtB <- rbind(result_1,result_2,result_3)


##############################################################################+
# A. MERGING RESULTS #####################

results <- rbind(results_ROA, results_Leverage, results_MtB)

write.csv(results, "e_drafts/results/Lag5/XGB/1_DML_Ind.csv")


