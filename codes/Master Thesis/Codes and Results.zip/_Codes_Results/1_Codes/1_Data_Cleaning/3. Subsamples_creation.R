#########################################################################+
# SAMPLE CREATONS+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(), "microdf"))
gc()

# 0. General

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

microdf <- read_csv("a_microdata/temp/microwd_var.csv")
microdf <- microdf %>% arrange(gvkey, fyear)
pdim(microdf) # Just to check if there loading still balanced

#############################################################+
# 1. GENERAL #################################################
# Squared terms, interactions, lagged values, means

#---------------------------------+
## 1.1 Define set of controls ####
X<- data.matrix(microdf[,c(6:27)]) # Not taking in account the sic code
dim(X) # Check the dimension of X

## 1.2 Interactions between X ####
X_interactions <- model.matrix(~.^2, data = as.data.frame(X))[, -1]
dim(X_interactions) #check de dimension of the interactions
## Note: this takes the interaction between variables + original variables

## 1.3 Squared terms ####
X_squared <- X^2
colnames(X_squared) <- paste0(colnames(X_squared), "^2") #renaming plus the ^2
dim(X_squared) #check dim, should the original number of controls

## 1.4 Binding Interactions and squared ####
new_X <- cbind(X_interactions, X_squared)
dim(new_X)

micro_cpx<- cbind(microdf[,c(1:5,28)],new_X)
micro_cpx <- micro_cpx %>% pdata.frame(index = c("gvkey", "fyear"))
pdim(micro_cpx)

## 1.5 Creating Lag values ####

### 1.5.1 Define the variables to Lag ####
# All excep the index and sic codes
columns_to_lag <- names(micro_cpx[,-c(1,2,6)])

### 1.5.2 Apply Lag period to those variables ####
micro_cpx_hd <- micro_cpx %>%
  arrange(gvkey, fyear) %>%  # Ensure correct ordering
  group_by(gvkey) %>%
  mutate(across(all_of(columns_to_lag), 
                list(
                  lag1 = ~ dplyr::lag(., 1, order_by = fyear),
                  lag2 = ~ dplyr::lag(., 2, order_by = fyear),
                  lag3 = ~ dplyr::lag(., 3, order_by = fyear),
                  lag4 = ~ dplyr::lag(., 4, order_by = fyear),
                  lag5 = ~ dplyr::lag(., 5, order_by = fyear)
                ), 
                .names = "{.col}_{.fn}")) %>%
  ungroup()


### 1.5.3 Remove the years 1980-1984
micro_cpx_hd <- micro_cpx_hd %>%
  mutate(fyear_num = as.numeric(as.character(fyear))) %>%  # Convert factor to numeric
  filter(fyear_num >= 1985) %>%
  select(-fyear_num)

## 1.6 Mean values
### 1.6.1 Define the variables to mean ####
columns_to_mean <- names(micro_cpx_hd[,-c(1,2,6)])

### 1.6.2 Calculate firm-specific means
firm_means <- micro_cpx_hd %>%
  group_by(gvkey) %>%
  summarise(across(all_of(columns_to_mean), mean, na.rm = TRUE, .names = "bar_{.col}"))

micro_cpx_hd_lag <- micro_cpx_hd %>%
  left_join(firm_means, by = "gvkey")

pdim(micro_cpx_hd_lag)

## 1.7 Convert sic to factor

micro_cpx_hd_lag <- micro_cpx_hd_lag %>% 
  arrange(gvkey, fyear) %>%
  mutate(sic = as.factor(sic))

## 1.8 SAVE FINAL SAMPLE
write_csv(micro_cpx_hd_lag, "a_microdata/temp/Sample_0.csv")
saveRDS(micro_cpx_hd_lag, "a_microdata/temp/Sample_0.rds")

#############################################################+
# 1. COMPLEX AND LAG  ########################################
# Squared terms, interactions, lagged values

subsample_0 <- readRDS("a_microdata/temp/Sample_0.rds")

subsample_1 <- subsample_0 %>% select(-starts_with("bar_"))

saveRDS(subsample_1, "a_microdata/temp/Sample_1.rds")

#############################################################+
# 2. SUBSAMPLE 2: Basic features only ####
# Lagged values

## 2.1 Identify original features (from microdf) ####
original_features <- c(names(microdf), 
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag1"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag2"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag3"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag4"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag5"))

# 2.2 Keep only original features and their lags
subsample_2 <- subsample_0 %>%
  select(any_of(original_features))

# 2.3 Save subsample
saveRDS(subsample_2, "a_microdata/temp/Sample_2.rds")

#############################################################+
# 3. SUBSAMPLE 3: Without squared/interactions ####
# Lagged values and means

original_features <- c(names(microdf), 
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag1"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag2"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag3"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag4"),
                       paste0(names(microdf[, -c(1,2, 28)]), "_lag5"),
                       paste0("bar_",names(microdf[, -c(1,2, 28)]))
                       )


subsample_3 <- subsample_0 %>%
  select(any_of(original_features))

saveRDS(subsample_3, "a_microdata/temp/Sample_3.rds")

##############################################################+
# 4. SUBSAMPLE 4: Without squared/interactions (Only Drivers) ####

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the data still balanced

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy
df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

# Creating delta versions
## Dependent
df$delta_RD_to_Assets = df$RD_to_Assets - df$RD_to_Assets_lag1
## D variables
df$delta_ROA = df$ROA - df$ROA_lag1
df$delta_Leverage = df$Leverage - df$Leverage_lag1
df$delta_Market_to_Book = df$Market_to_Book - df$Market_to_Book_lag1
df$delta_ROA.Leverage = df$ROA.Leverage - df$ROA.Leverage_lag1
df$delta_ROA.Market_to_Book = df$ROA.Market_to_Book - df$ROA.Market_to_Book_lag1
df$delta_Leverage.Market_to_Book = df$Leverage.Market_to_Book - df$Leverage.Market_to_Book_lag1

# Remove lag variables and original variables
df <- df %>% select(-matches("lag[1-5]"))
df <- df %>% select(-c("ROA", "Leverage", "Market_to_Book", "RD_to_Assets")) %>% 
  select(gvkey, fyear, delta_RD_to_Assets,
         delta_ROA, delta_Leverage, delta_Market_to_Book,
         delta_ROA.Leverage, delta_ROA.Market_to_Book, delta_Leverage.Market_to_Book,
         everything())

df <- df[,-c(29:281)]

saveRDS(df, "a_microdata/temp/Sample_4.rds")
