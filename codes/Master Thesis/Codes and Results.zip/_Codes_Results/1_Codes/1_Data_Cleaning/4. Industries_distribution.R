#########################################################################+
# SAMPLE CREATONS+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(), "microdf"))
gc()

# 0. General

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

microdf <- read_csv("a_microdata/temp/microwd_var.csv")
microdf <- microdf %>% arrange(gvkey, fyear)
pdim(microdf) # Just to check if there loading still balanced


## 0.3 SIC BY INDUSTRIES
firm_counts <- microdf %>% 
  distinct(gvkey, sic) %>%   
  count(sic, name = "n_firms") %>% 
  arrange(desc(n_firms))

print(firm_counts)


firm_counts_2dig <- microdf %>% 
  mutate(sic2 = str_sub(as.character(sic), 1, 2)) %>%   # keep first 2 chars
  distinct(gvkey, sic2) %>%                             # one row per firm–2-digit SIC
  count(sic2, name = "n_firms") %>%                     # how many firms?
  arrange(desc(n_firms))                                # sort, largest → smallest

print(firm_counts_2dig)


firm_counts_1dig <- microdf %>% 
  mutate(sic1 = str_sub(as.character(sic), 1, 1)) %>%   # keep first 2 chars
  distinct(gvkey, sic1) %>%                             # one row per firm–2-digit SIC
  count(sic1, name = "n_firms") %>%                     # how many firms?
  arrange(desc(n_firms))                                # sort, largest → smallest

print(firm_counts_1dig)

microdf$RD_to_Assets


#################
sic2_RD_means <- microdf %>% 
  mutate(sic2 = str_sub(sprintf("%04s", sic), 1, 1)) %>%   # two-digit code
  group_by(sic2) %>% 
  summarise(
    mean_RD_to_Assets = mean(RD_to_Assets, na.rm = TRUE),
    n_obs           = n()
  ) %>% 
  arrange(desc(mean_RD_to_Assets))

print(sic2_RD_means)