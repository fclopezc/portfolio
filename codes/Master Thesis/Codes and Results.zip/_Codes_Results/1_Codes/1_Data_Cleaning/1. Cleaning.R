# clear console ####
cat("/014")
rm(list = setdiff(ls(), "microdf"))
gc()


# Import ####
microdf <- read_csv("a_microdata/Compustat_AF.csv")

microwd <- microdf

# Filter Data ####
microwd <- microwd %>%
  filter(fyear >= 1980 & fyear <= 2019) %>% # Movaghari et al (2024)
  group_by(gvkey) %>%
  filter(!is.na(fyear)) %>% # FL
  filter(all(sale > 0)) %>% # Movaghari et al (2024)
  filter(all(act > 0)) %>% # FL
  filter(all(emp > 0)) %>% # FL
  mutate(book_value_of_equity = at - (lct + dltt)) %>% # Movaghari et al (2024)
  filter(all(book_value_of_equity > 0)) %>% # Movaghari et al (2024)
  filter(all(che > 0)) %>% # Movaghari et al (2024)
  filter(!(sic >= 6000 & sic <= 6999) & !(sic >= 4900 & sic <= 4999)) %>% # Movaghari et al (2024)
  mutate(xrd = replace_na(xrd, 0)) %>% # Movaghari et al (2024)
  mutate(xad = replace_na(xad, 0)) %>% # FL
  #filter(costat=="A") %>%
  ungroup()

# Inducing balance panel ####
microwd <- microwd %>%
  group_by(gvkey) %>%
  mutate(n_years = n_distinct(fyear)) %>%
  filter(n_years == 40) %>%
  ungroup() %>%
  pdata.frame(index = c("gvkey", "fyear"))


# check balance
is.pbalanced(microwd)
pdim(microwd)

# Save data ####
write_csv(microwd, "a_microdata/temp/microwd.csv")




