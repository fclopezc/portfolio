#clear console
cat("/014")
rm(list = setdiff(ls(), "microdf"))
gc()

# Compustat ####

## Import ####
microdf <- read_csv("a_microdata/temp/microwd.csv")

microwd <- microdf %>% pdata.frame(index = c("gvkey", "fyear"))

is.pbalanced(microwd)
pdim(microwd)

microwd <- microwd %>%
  mutate(across(9:43, ~ ifelse(is.na(.), 0, .)))


# Create the required variables
microwd <- microwd %>%
  mutate(
    # Dependent Variables
    RD_to_Assets = xrd / at,
    RD_to_Sales = xrd / sale,
    Log_RD = log(xrd + 1),  # Adding 1 to avoid log(0)
    
    # Proposed Drivers
    ROA = ni / at,
    Tangibility = (0.715 * rect + 0.547 * invt + 0.535 * ppent) / at,
    Intangible_Assets = (intan + xrd) / at,
    Firm_Size = log(at),
    Leverage = (dltt + dlc) / at,
    Market_to_Book = (prcc_f * csho) / at,
    Cash_Flow = (oibdp - xint - txt - dvc) / at,
    Sales = log(sale*1000000),
    Employment = log(emp*1000),
    Book_eq = book_value_of_equity/ at,
    
    # Firm-Level Control Variables
    Dividend_Payments = ifelse(dvc > 0, 1, 0),
    Advertising_Expenditures = xad / at,
    Net_Working_Capital = (act - lct - che) / at,
    Negative_Income = ifelse(ni < 0, 1, 0),
    Sale_of_PPE = ifelse(sppe > 0, 1, 0),
    Acquisitions = aqc / at,
    Capital_Expenditure = capx / at,
    Foreign_Income = pifo / at,
    Domestic_Income = pidom / at,
    Net_Debt_Issuance = (dltis - dltr) / at,
    Net_Equity_Issuance = (sstk - dv - prstkc) / at,
    #Effective_Tax_Rate = txt / pi,
    Cash_to_Assets = che / at
  )


# List of newly created variables
new_vars <- c(
  "RD_to_Assets", "RD_to_Sales", "Log_RD", "ROA", "Tangibility", "Intangible_Assets", 
  "Firm_Size", "Leverage", "Market_to_Book", "Cash_Flow", "Sales", "Employment","Book_eq", 
  "Dividend_Payments", "Advertising_Expenditures", "Net_Working_Capital", 
  "Negative_Income", "Sale_of_PPE", "Acquisitions", "Capital_Expenditure", "Foreign_Income", 
  "Domestic_Income", "Net_Debt_Issuance", "Net_Equity_Issuance", "Cash_to_Assets"
)

# Initialize an empty data frame to store the report
report <- data.frame(
  Variable = character(),
  Missing = numeric(),
  Zero = numeric(),
  Non_Zero = numeric(),
  Inf_Values = numeric(),
  Neg_Inf_Values = numeric(),
  stringsAsFactors = FALSE
)

# Loop through each variable and calculate counts
for (var in new_vars) {
  missing_count <- sum(is.na(microwd[[var]]))
  zero_count <- sum(microwd[[var]] == 0, na.rm = TRUE)
  non_zero_count <- sum(microwd[[var]] != 0, na.rm = TRUE)
  inf_count <- sum(microwd[[var]] == Inf, na.rm = TRUE)
  neg_inf_count <- sum(microwd[[var]] == -Inf, na.rm = TRUE)
  
  # Append the results to the report
  report <- rbind(report, data.frame(
    Variable = var,
    Missing = missing_count,
    Zero = zero_count,
    Non_Zero = non_zero_count,
    Inf_Values = inf_count,
    Neg_Inf_Values = neg_inf_count,
    stringsAsFactors = FALSE
  ))
}

# Print the report
print(report)

microwd <- microwd %>%
  select(c(1, 3, all_of(new_vars)),42)

# SAVE DATA ####
write_csv(microwd, "a_microdata/temp/microwd_var.csv")
