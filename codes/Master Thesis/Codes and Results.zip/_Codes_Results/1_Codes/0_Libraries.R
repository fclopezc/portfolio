####################################################+
# LIBRARIES USED
####################################################+

# Data Cleaning / Processing / Visualization
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(stargazer)
library(knitr)
library(kableExtra)
library(data.table)
library(doParallel)
library(future)
library(sandwich)
library(lmtest)
library(stringr)

# Panel Data
library(plm)
library(pdynmc)
library(pgmm)

# Double Machine Learning / ML
library(glmnet)
library(hdm)
library(DoubleML)
library(mlr3)
library(gamlr)
library(XTDML)
library(rpart)
library(xgboost)
library(mlr3pipelines)
library(caret)

## ML tunning
library(mlr3)
library(mlr3learners)
library(mlr3verse)
library(mlr3misc)
library(mlr3tuning)
library(paradox)
library(MLmetrics)
