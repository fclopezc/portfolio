#########################################################################+
# LASSO: CRE ############################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("df", "ROA_CRE_Theo","ROA_CRE_CV",
                         "Leverage_CRE_Theo","Leverage_CRE_CV",
                         "MtB_CRE_Theo","MtB_CRE_CV")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_0.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Parameters for theoretical lambdas
inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)

##############################################################################+
# 1. ROA ######################################################################

## 1.0 Creating the object #####

exclude_cols <- c("gvkey", "fyear", "ROA_lag5", "RD_to_Assets")
bar_cols <- grep("^bar_", names(df), value = TRUE)
x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))

xbar_cols <- bar_cols[!bar_cols %in% c("bar_ROA_lag5", "bar_RD_to_Assets")]

setDT(df)

# set up data for DML procedure
dml_data = dml_cre_data_from_data_frame(df,
                                            x_cols = x_cols,  y_col = "RD_to_Assets", d_cols = "ROA_lag5",
                                            xbar_cols = xbar_cols, dbar_cols = "bar_ROA_lag5",
                                            cluster_cols = "gvkey")

remove(bar_cols);remove(exclude_cols);remove(x_cols);remove(xbar_cols)

gc()

## 1.1 Theoretical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )

dml_plr_lasso_theorical = dml_cre_plr$new(dml_data,
                ml_l = ml_l, ml_m = ml_m,
                score = "orth-PO",
                dml_procedure = "dml2",
                dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions = TRUE)

ROA_CRE_Theo <- dml_plr_lasso_theorical$summary()

rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)


colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

ROA_CRE_Theo <- cbind(ROA_CRE_Theo,rmse_l,rmse_m,rmse_model)

gc()

## 1.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)

dml_plr_lasso_cv = dml_cre_plr$new(dml_data,
                                   ml_l = ml_l, ml_m = ml_m,
                                   score = "orth-PO",
                                   dml_procedure = "dml2",
                                   dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_cv$fit(store_predictions = TRUE)


ROA_CRE_CV <- dml_plr_lasso_cv$summary()

rmse_l <- dml_plr_lasso_cv$rmses$ml_l
rmse_m <- dml_plr_lasso_cv$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)

colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

ROA_CRE_CV <- cbind(ROA_CRE_CV,rmse_l,rmse_m,rmse_model)

gc()

##############################################################################+
# 2. Leverage #################################################################

## 2.0 Creating the object ####

exclude_cols <- c("gvkey", "fyear", "Leverage_lag5", "RD_to_Assets")
bar_cols <- grep("^bar_", names(df), value = TRUE)
x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))

xbar_cols <- bar_cols[!bar_cols %in% c("bar_Leverage_lag5", "bar_RD_to_Assets")]

setDT(df)

# set up data for DML procedure
dml_data = dml_cre_data_from_data_frame(df,
                                        x_cols = x_cols,  y_col = "RD_to_Assets", d_cols = "Leverage_lag5",
                                        xbar_cols = xbar_cols, dbar_cols = "bar_Leverage_lag5",
                                        cluster_cols = "gvkey")

remove(bar_cols);remove(exclude_cols);remove(x_cols);remove(xbar_cols)
gc()

## 2.1 Theoretical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )
dml_plr_lasso_theorical = dml_cre_plr$new(dml_data,
                                          ml_l = ml_l, ml_m = ml_m,
                                          score = "orth-PO",
                                          dml_procedure = "dml2",
                                          dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions = TRUE)

Leverage_CRE_Theo <- dml_plr_lasso_theorical$summary()

rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)


colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

Leverage_CRE_Theo <- cbind(Leverage_CRE_Theo,rmse_l,rmse_m,rmse_model)

gc()

## 2.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)

dml_plr_lasso_cv = dml_cre_plr$new(dml_data,
                                   ml_l = ml_l, ml_m = ml_m,
                                   score = "orth-PO",
                                   dml_procedure = "dml2",
                                   dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_cv$fit(store_predictions = TRUE)

Leverage_CRE_CV <- dml_plr_lasso_cv$summary()

rmse_l <- dml_plr_lasso_cv$rmses$ml_l
rmse_m <- dml_plr_lasso_cv$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)

colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

Leverage_CRE_CV <- cbind(Leverage_CRE_CV,rmse_l,rmse_m,rmse_model)

gc()

##############################################################################+
# 3. Market to Book ###########################################################

## 3.0 Creating the object ####

exclude_cols <- c("gvkey", "fyear", "Market_to_Book_lag5", "RD_to_Assets")
bar_cols <- grep("^bar_", names(df), value = TRUE)
x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))

xbar_cols <- bar_cols[!bar_cols %in% c("bar_Market_to_Book_lag5", "bar_RD_to_Assets")]

setDT(df)

# set up data for DML procedure
dml_data = dml_cre_data_from_data_frame(df,
                                        x_cols = x_cols,  y_col = "RD_to_Assets", d_cols = "Market_to_Book_lag5",
                                        xbar_cols = xbar_cols, dbar_cols = "bar_Market_to_Book_lag5",
                                        cluster_cols = "gvkey")

remove(bar_cols);remove(exclude_cols);remove(x_cols);remove(xbar_cols)
gc()

## 3.1 Theoretical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )

dml_plr_lasso_theorical = dml_cre_plr$new(dml_data,
                                          ml_l = ml_l, ml_m = ml_m,
                                          score = "orth-PO",
                                          dml_procedure = "dml2",
                                          dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions = TRUE)

MtB_CRE_Theo <- dml_plr_lasso_theorical$summary()

rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)


colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

MtB_CRE_Theo <- cbind(MtB_CRE_Theo,rmse_l,rmse_m,rmse_model)

gc()

## 3.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)

dml_plr_lasso_cv = dml_cre_plr$new(dml_data,
                                   ml_l = ml_l, ml_m = ml_m,
                                   score = "orth-PO",
                                   dml_procedure = "dml2",
                                   dml_approach  = "cre",n_folds = 10)

dml_plr_lasso_cv$fit(store_predictions = TRUE)

MtB_CRE_CV <- dml_plr_lasso_cv$summary()

rmse_l <- dml_plr_lasso_cv$rmses$ml_l
rmse_m <- dml_plr_lasso_cv$rmses$ml_m
rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)

colnames(rmse_l) <- c("rmse_l")
colnames(rmse_m) <- c("rmse_m")
colnames(rmse_model) <- c("rmse_model")

MtB_CRE_CV <- cbind(MtB_CRE_CV,rmse_l,rmse_m,rmse_model)

gc()

##############################################################################+
# A. MERGE RESULTS ############################################################

results <- rbind(ROA_CRE_Theo,ROA_CRE_CV,
                        Leverage_CRE_Theo,Leverage_CRE_CV,
                        MtB_CRE_Theo,MtB_CRE_CV)

colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value",
                       "rmse_l","rmse_m","rmse_model")
rownames(results) <- c("ROA_Theo","ROA_CV",
                       "Leverage_Theo","Leverage_CV",
                       "MtB_Theo","MtB_CV")

write.csv(results, "e_drafts/results/Lag5/LASSO/2_CRE_Lag5.csv")
