library(DoubleML)
library(data.table)
library(mlr3learners)
library(beepr)

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("DML_Theo")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Parameters for theoretical lambdas
inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)

set.seed(123)

# Define outcome and covariates
outcome_var <- "RD_to_Assets"
exclude_vars <- c("gvkey", "fyear", outcome_var)

# Define treatment variables

treatments <- c("ROA_lag5", "Leverage_lag5", "Market_to_Book_lag5")

#########################################################+
# THEORICAL LAMBDA #####
#########################################################+

# Shared learners
ml_l <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE,
            intercept = FALSE, lambda = lambda.outcome)

ml_m <- lrn("regr.glmnet", family = "gaussian", standardize = TRUE,
            intercept = FALSE, lambda = lambda.treat)

# Store results
results_list <- list()
rmse_ml_l <- list()
rmse_ml_m <- list()

#-------------------------------------------#
# Loop over each treatment
#-------------------------------------------#
for (treat in treatments) {
  
  # Define X cols
  x_cols <- setdiff(names(df), c(exclude_vars, treat))
  
  # Create DoubleMLData object
  dml_data <- DoubleMLData$new(
    data = as.data.table(df),
    y_col = outcome_var,
    d_cols = treat,
    x_cols = x_cols
  )
  
  # Fit DML model
  dml_model <- DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
  dml_model$fit(store_predictions = TRUE)
  
  # Compute RMSE of the causal residual regression
  y <- df[[outcome_var]]
  d <- df[[treat]]
  g_hat <- dml_model$predictions$ml_l
  m_hat <- dml_model$predictions$ml_m
  
  rmse_l <- RMSE(g_hat,y)
  rmse_m <- RMSE(m_hat,d)
  
  # Store results
  results_list[[treat]] <- dml_model$summary()
  rmse_ml_l[[treat]] <- rmse_l
  rmse_ml_m[[treat]] <- rmse_m
}

DML_Theo <- rbind(results_list$ROA_lag5,
                  results_list$Leverage_lag5,
                  results_list$Market_to_Book_lag5)



DML_Theo_rmse_l <- rbind(rmse_ml_l$ROA_lag5,
                         rmse_ml_l$Leverage_lag5,
                         rmse_ml_l$Market_to_Book_lag5)

DML_Theo_rmse_m <- rbind(rmse_ml_m$ROA_lag5,
                         rmse_ml_m$Leverage_lag5,
                         rmse_ml_m$Market_to_Book_lag5)

colnames(DML_Theo_rmse_l) <- c("RMSE_l")
colnames(DML_Theo_rmse_m) <- c("RMSE_m")

DML_Theo <- cbind(DML_Theo,DML_Theo_rmse_l,DML_Theo_rmse_m)

rownames(DML_Theo) <- c("ROA_Theo","Leverage_Theo","MtB_Theo")


#########################################################+
# CV LAMBDA #####
#########################################################+

# Shared learners
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)

ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)

# Store results
results_list <- list()
rmse_ml_l <- list()
rmse_ml_m <- list()

#-------------------------------------------#
# Loop over each treatment
#-------------------------------------------#
for (treat in treatments) {
  
  # Define X cols
  x_cols <- setdiff(names(df), c(exclude_vars, treat))
  
  # Create DoubleMLData object
  dml_data <- DoubleMLData$new(
    data = as.data.table(df),
    y_col = outcome_var,
    d_cols = treat,
    x_cols = x_cols
  )
  
  # Fit DML model
  dml_model <- DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
  dml_model$fit(store_predictions = TRUE)
  
  # Compute RMSE of the causal residual regression
  y <- df[[outcome_var]]
  d <- df[[treat]]
  g_hat <- dml_model$predictions$ml_l
  m_hat <- dml_model$predictions$ml_m
  
  rmse_l <- RMSE(g_hat,y)
  rmse_m <- RMSE(m_hat,d)
  
  # Store results
  results_list[[treat]] <- dml_model$summary()
  rmse_ml_l[[treat]] <- rmse_l
  rmse_ml_m[[treat]] <- rmse_m
}

DML_CV <- rbind(results_list$ROA_lag5,
                  results_list$Leverage_lag5,
                  results_list$Market_to_Book_lag5)



DML_CV_rmse_l <- rbind(rmse_ml_l$ROA_lag5,
                         rmse_ml_l$Leverage_lag5,
                         rmse_ml_l$Market_to_Book_lag5)

DML_CV_rmse_m <- rbind(rmse_ml_m$ROA_lag5,
                         rmse_ml_m$Leverage_lag5,
                         rmse_ml_m$Market_to_Book_lag5)

colnames(DML_CV_rmse_l) <- c("RMSE_l")
colnames(DML_CV_rmse_m) <- c("RMSE_m")

DML_CV <- cbind(DML_CV,DML_CV_rmse_l,DML_CV_rmse_m)

##############################################################################+
# A. MERGE RESULTS ############################################################

results <- rbind(DML_Theo,DML_CV)

write.csv(results, "e_drafts/results/Lag5/LASSO/1_DML_Lag5.csv")


