  #########################################################################+
  # LASSO: DML ############################################################+
  #########################################################################+
  
  # CLEANING CONSOLE ####
  cat("/014")
  rm(list = setdiff(ls(),c("df", "ROA_FD_Theo","ROA_FD_CV",
                           "Leverage_FD_Theo","Leverage_FD_CV",
                           "MtB_FD_Theo","MtB_FD_CV")))
  gc()
  
  # 0. General ####
  
  ## 0.1 LOADING LIBRARIES ####
  source("c_code/0_Libraries.R")
  future::plan("multisession", workers = availableCores() - 1)
  
  
  ## 0.2 LOADING DATASET WITH VARIABLES ####
  
  df <- readRDS("a_microdata/temp/Sample_1.rds")
  plm::is.pbalanced(df) # check the datastill balance
  
  # Remove the other options of Y
  df <- df %>% select(-matches("RD_to_Sales|Log_RD"))
  
  # convert `sic` into dummy
  
  df <- cbind(
    df %>% select(-sic),
    model.matrix(~ sic - 1, data = df))
  
  ## 0.3 creating delta variables ####
  
  # Remove the lag values from 2 to 5
  df <- df %>%select(-matches("lag[2-5]"))
  
  # Creating delta versions
  ## Dependent
  df$delta_RD_to_Assets = df$RD_to_Assets - df$RD_to_Assets_lag1
  ## D
  df$delta_ROA = df$ROA-df$ROA_lag1
  df$delta_Leverage = df$Leverage-df$Leverage_lag1
  df$delta_Market_to_Book = df$Market_to_Book-df$Market_to_Book_lag1
  
  df <- df %>%select(-matches("lag1"))
  
  df <- df %>% 
    select(-c("ROA","Leverage","Market_to_Book","RD_to_Assets")) %>% 
    select(gvkey, fyear, delta_RD_to_Assets,
           delta_ROA,delta_Leverage,delta_Market_to_Book,
           everything())
  
  
  ## 0.4 Parameters for theoretical lambdas ####
  inds_train<-(1:dim(df)[1])
  
  n_items<-length(unique(df$gvkey)) # Number of firms
  
  # Set the lambdas for nuisance functions
  lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
  lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
  
  remove(inds_train);remove(n_items)
  
  ##############################################################################+
  # 1. ROA ######################################################################
  
  ## 1.0 Creating the object #####
  
  xvars <- setdiff(names(df), 
                   c("gvkey", "fyear", "delta_ROA", "delta_RD_to_Assets"))
  
  dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                              x_cols = xvars,
                                              y_col = "delta_RD_to_Assets",
                                              d_cols = "delta_ROA",
                                              cluster_cols = "gvkey")
  
  remove(xvars);gc()
  
  
  ## 1.1 Theorical lambdas ####
  #-----------------------------------------+
  
  set.seed(123)
  ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.outcome )
  ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.treat )
  
  dml_plr_lasso_theorical = dml_approx_plr$new(dml_data,
                                               ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_theorical$fit(store_predictions = TRUE)
  
  ROA_FD_Theo <- dml_plr_lasso_theorical$summary()
  
  rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
  rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)
  
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  ROA_FD_Theo <- cbind(ROA_FD_Theo,rmse_l,rmse_m,rmse_model)
  
  
  gc(); beepr::beep(sound = 2)
  
  ## 1.2 Cross validation ####
  #-----------------------------------------+
  set.seed(123)
  ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min", nfolds = 10)
  ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min",nfolds = 10)
  
  dml_plr_lasso_cv = dml_approx_plr$new(dml_data,
                                        ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_cv$fit(store_predictions = TRUE)
  
  ROA_FD_CV <- dml_plr_lasso_cv$summary()
  
  rmse_l <- dml_plr_lasso_cv$rmses$ml_l
  rmse_m <- dml_plr_lasso_cv$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  ROA_FD_CV <- cbind(ROA_FD_CV,rmse_l,rmse_m,rmse_model)
  
  gc(); beepr::beep(sound = 2)
  
  ##############################################################################+
  # 2. Leverage #################################################################
  
  ## 2.0 Creating the object ####
  
  xvars <- setdiff(names(df), 
                   c("gvkey", "fyear", "delta_Leverage", "delta_RD_to_Assets"))
  
  dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                              x_cols = xvars,
                                              y_col = "delta_RD_to_Assets",
                                              d_cols = "delta_Leverage",
                                              cluster_cols = "gvkey")
  
  remove(xvars);gc()
  
  ## 2.1 Theoretical lambdas ####
  #-----------------------------------------+
  
  set.seed(123)
  ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.outcome )
  ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.treat )
  
  dml_plr_lasso_theorical = dml_approx_plr$new(dml_data,
                                               ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_theorical$fit(store_predictions = TRUE)
  
  Leverage_FD_Theo <- dml_plr_lasso_theorical$summary()
  
  rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
  rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)
  
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  Leverage_FD_Theo <- cbind(Leverage_FD_Theo,rmse_l,rmse_m,rmse_model)
  
  gc(); beepr::beep(sound = 2)
  
  ## 2.2 Cross validation ####
  #-----------------------------------------+
  set.seed(123)
  ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min", nfolds = 10)
  ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min",nfolds = 10)
  
  dml_plr_lasso_cv = dml_approx_plr$new(dml_data,
                                        ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_cv$fit(store_predictions = TRUE)
  
  Leverage_FD_CV <- dml_plr_lasso_cv$summary()
  
  rmse_l <- dml_plr_lasso_cv$rmses$ml_l
  rmse_m <- dml_plr_lasso_cv$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  Leverage_FD_CV <- cbind(Leverage_FD_CV,rmse_l,rmse_m,rmse_model)
  
  gc(); beepr::beep(sound = 2)
  
  ##############################################################################+
  # 3. Market to Book ###########################################################
  
  ## 3.0 Creating the object ####
  
  xvars <- setdiff(names(df), 
                   c("gvkey", "fyear", "delta_Market_to_Book", "delta_RD_to_Assets"))
  
  dml_data <- dml_approx_data_from_data_frame(data.table::as.data.table(df),
                                              x_cols = xvars,
                                              y_col = "delta_RD_to_Assets",
                                              d_cols = "delta_Market_to_Book",
                                              cluster_cols = "gvkey")
  
  remove(xvars);gc()
  
  ## 3.1 Theoretical lambdas ####
  #-----------------------------------------+
  
  set.seed(123)
  ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.outcome )
  ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             lambda= lambda.treat )
  
  dml_plr_lasso_theorical = dml_approx_plr$new(dml_data,
                                               ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_theorical$fit(store_predictions = TRUE)
  
  MtB_FD_Theo <- dml_plr_lasso_theorical$summary()
  
  rmse_l <- dml_plr_lasso_theorical$rmses$ml_l
  rmse_m <- dml_plr_lasso_theorical$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_theorical$model_rmse)
  
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  MtB_FD_Theo <- cbind(MtB_FD_Theo,rmse_l,rmse_m,rmse_model)
  
  gc(); beepr::beep(sound = 2)
  
  ## 3.2 Cross validation ####
  #-----------------------------------------+
  set.seed(123)
  ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min", nfolds = 10)
  ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
             s="lambda.min",nfolds = 10)
  
  dml_plr_lasso_cv = dml_approx_plr$new(dml_data,
                                        ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  dml_plr_lasso_cv$fit(store_predictions = TRUE)
  
  MtB_FD_CV <- dml_plr_lasso_cv$summary()
  
  rmse_l <- dml_plr_lasso_cv$rmses$ml_l
  rmse_m <- dml_plr_lasso_cv$rmses$ml_m
  rmse_model <- as.matrix(dml_plr_lasso_cv$model_rmse)
  
  colnames(rmse_l) <- c("rmse_l")
  colnames(rmse_m) <- c("rmse_m")
  colnames(rmse_model) <- c("rmse_model")
  
  MtB_FD_CV <- cbind(MtB_FD_CV,rmse_l,rmse_m,rmse_model)
  
  gc(); beepr::beep(sound = 2)
  
  ##############################################################################+
  # A. MERGE RESULTS ############################################################
  
  results <- unname(rbind(ROA_FD_Theo,ROA_FD_CV,
                          Leverage_FD_Theo,Leverage_FD_CV,
                          MtB_FD_Theo,MtB_FD_CV))
  
  colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value",
                         "rmse_l","rmse_m","rmse_model")
  
  rownames(results) <- c("ROA_Theo","ROA_CV",
                         "Leverage_Theo","Leverage_CV",
                         "MtB_Theo","MtB_CV")
  
  write.csv(results, "e_drafts/results/LASSO/3_FD_Ind.csv")