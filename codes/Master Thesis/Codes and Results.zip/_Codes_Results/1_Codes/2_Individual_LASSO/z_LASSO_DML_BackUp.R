#########################################################################+
# LASSO: DML ############################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("df", "ROA_DML_Theo","ROA_DML_CV",
                         "Leverage_DML_Theo","Leverage_DML_CV",
                         "MtB_DML_Theo","MtB_DML_CV")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_1.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Parameters for theoretical lambdas
inds_train<-(1:dim(df)[1])

n_items<-length(unique(df$gvkey)) # Number of firms

# Set the lambdas for nuisance functions
lambda.treat=2*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))
lambda.outcome=0.05*(log(length(inds_train)))^(3/2)/sqrt(length(inds_train))

remove(inds_train);remove(n_items)

##############################################################################+
# 1. ROA ######################################################################

## 1.0 Creating the object #####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "ROA",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "ROA", "RD_to_Assets"))
)

## 1.1 Theorical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )

dml_plr_lasso_theorical = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)

dml_plr_lasso_theorical$fit(store_predictions= TRUE)

dml_plr_lasso_theorical$score


# Step 1: Residuals from outcome and treatment models
y <- df[,dml_plr_lasso_theorical$data$y_col]
d <- df[,dml_plr_lasso_theorical$data$d_cols]
g_hat <- dml_plr_lasso_theorical$predictions$ml_l
m_hat <- dml_plr_lasso_theorical$predictions$ml_m

res_y <- y - g_hat
res_d <- d - m_hat

# Step 2: Fit the final stage manually
final_model <- lm(res_y ~ res_d)

# Step 3: Predicted residuals and RMSE
preds <- predict(final_model)
rmse_final <- sqrt(mean((res_y - preds)^2))
print(rmse_final)


ROA_DML_Theo <- dml_plr_lasso_theorical$summary()

## 1.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)
dml_plr_lasso_cv = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
dml_plr_lasso_cv$fit()
ROA_DML_CV <- dml_plr_lasso_cv$summary()

##############################################################################+
# 2. Leverage #################################################################

## 2.0 Creating the object ####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "Leverage",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "Leverage", "RD_to_Assets")))

## 2.1 Theoretical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )
dml_plr_lasso_theorical = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)

dml_plr_lasso_theorical$fit()

Leverage_DML_Theo <- dml_plr_lasso_theorical$summary()

## 2.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)
dml_plr_lasso_cv = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
dml_plr_lasso_cv$fit()
Leverage_DML_CV <- dml_plr_lasso_cv$summary()

beepr::beep(sound = 2)


##############################################################################+
# 3. Market to Book ###########################################################

## 3.0 Creating the object ####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = "Market_to_Book",
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear", "Market_to_Book", "RD_to_Assets")))

## 3.1 Theoretical lambdas ####
#-----------------------------------------+

set.seed(123)
ml_l = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.outcome )
ml_m = lrn("regr.glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           lambda= lambda.treat )
dml_plr_lasso_theorical = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)

dml_plr_lasso_theorical$fit()

MtB_DML_Theo <- dml_plr_lasso_theorical$summary()

beepr::beep(sound = 2)

## 3.2 Cross validation ####
#-----------------------------------------+
set.seed(123)
ml_l = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min", nfolds = 10)
ml_m = lrn("regr.cv_glmnet",family = "gaussian",standardize = TRUE,intercept = FALSE, 
           s="lambda.min",nfolds = 10)
dml_plr_lasso_cv = DoubleMLPLR$new(dml_data, ml_l, ml_m, n_folds = 10)
dml_plr_lasso_cv$fit()
MtB_DML_CV <- dml_plr_lasso_cv$summary()

beepr::beep(sound = 2)

##############################################################################+
# A. MERGE RESULTS ############################################################

results <- unname(rbind(ROA_DML_Theo,ROA_DML_CV,
                        Leverage_DML_Theo,Leverage_DML_CV,
                        MtB_DML_Theo,MtB_DML_CV))

colnames(results) <- c("Estimate", "Std. Error", "t value", "Pr.Value")
rownames(results) <- c("ROA_Theo","ROA_CV",
                       "Leverage_Theo","Leverage_CV",
                       "MtB_Theo","MtB_CV")

results_formatted <- data.frame(
  Estimate = sprintf("%.4f", results[,1]),
  Std.Error = sprintf("%.4f", results[,2]),
  t.value = sprintf("%.4f", results[,3]),
  p.value = formatC(results[,4], format = "e", digits = 2)
)
rownames(results_formatted) <- rownames(results)


write.csv(results_formatted, "e_drafts/results/LASSO/DML_Ind_0515.csv")