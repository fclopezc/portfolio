#########################################################################+
# XGBoost: DML ##########################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list=ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_2.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

## 0.3 Define treatments ####

treatments <- c("ROA", "Leverage", "Market_to_Book")
interactions <- c("ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
y_var <- "RD_to_Assets"

## 0.4 XGBoost function ####

run_dml <- function(ntrees) {
  cat("Running DML with tuning of depth and eta\n")
  
  # Define parameter grid
  param_grid = list(
    "ml_l" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    ),
    "ml_m" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    )
  )
  
  # Base learner with fixed parameters
  #learner <- lrn("regr.xgboost",nrounds = ntrees,lambda = 1,alpha = 0)
  
  learner <- lrn("regr.xgboost",
                 nrounds = ntrees,
                 early_stopping_rounds = 5,
                 validate = 0.1,
                 lambda = 1,
                 alpha = 0)
  
  # Clone for ml_l and ml_m
  ml_l <- learner$clone()
  ml_m <- learner$clone()
  
  # Create DML object
  dml_plr <- DoubleMLPLR$new(data = dml_data, ml_l = ml_l, ml_m = ml_m, n_folds = 4)
  
  # Tune depth and eta
  set.seed(123)
  dml_plr$tune(
    param_set = param_grid,
    tune_settings = list(
      terminator = trm("evals", n_evals = 2),
      algorithm = tnr("random_search"),
      rsmp_tune = rsmp("cv", folds = 2),
      measure = list("ml_l" = msr("regr.mse"), "ml_m" = msr("regr.mse"))
    ),
    tune_on_folds = FALSE
  )
  
  dml_plr$fit(store_predictions = TRUE)
  
  # Get standard summary
  result_summary <- dml_plr$summary()
 
  beepr::beep(sound = 2)
  gc()
  
  return(model = dml_plr)
  #return(summary = result_summary)
}

## 0.5 Summary function #####

summarize_dml_results <- function(dml_result, df, treatments, model_name = "model") {
  # Calculate RMSE for ml_l predictions
  rmse_l <- as.matrix(rep(RMSE(dml_result$predictions$ml_l, df$RD_to_Assets), length(treatments)))
  colnames(rmse_l) <- c("RMSE_l")
  
  # Calculate RMSE for each treatment in ml_m predictions
  resid_m <- as.matrix.data.frame(dml_result$predictions$ml_m)
  colnames(resid_m) <- treatments
  
  rmse_m <- sapply(seq_along(treatments), function(i) {
    RMSE(resid_m[, i], df[[treatments[i]]])
  })
  rmse_m <- as.matrix(rmse_m)
  colnames(rmse_m) <- c("RMSE_m")
  
  # Extract eta and depth parameters for each treatment
  extract_params <- function(param_type, learner_type) {
    sapply(treatments, function(treatment) {
      dml_result$params[[learner_type]][[treatment]][[param_type]]
    })
  }
  
  eta_l <- as.matrix(extract_params("eta", "ml_l"))
  colnames(eta_l) <- c("eta_l")
  
  depth_l <- as.matrix(extract_params("max_depth", "ml_l"))
  colnames(depth_l) <- c("depth_l")
  
  eta_m <- as.matrix(extract_params("eta", "ml_m"))
  colnames(eta_m) <- c("eta_m")
  
  depth_m <- as.matrix(extract_params("max_depth", "ml_m"))
  colnames(depth_m) <- c("depth_m")
  
  # Combine all results
  result_table <- cbind(
    dml_result$summary(),
    eta_l,
    depth_l,
    rmse_l,
    eta_m,
    depth_m,
    rmse_m
  )
  
  # Assign to a variable with the specified model name
  assign(model_name, result_table, envir = .GlobalEnv)
  
  # Also return the result in case you want to capture it
  return(result_table)
}

#########################################################################+
# RUNING ANALYSIS ########################################################
#########################################################################+

## 1.0 Creating the object #####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = treatments,
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear","RD_to_Assets",treatments))
)

## 1.1 100 trees ####

result_1 <- run_dml(ntrees=20)

NoInt_20 <- summarize_dml_results(result_1, df, treatments, "NoInt_100")

result_1$summary()

rmse_l <- as.matrix(rep(RMSE(result_1$predictions$ml_l,df$RD_to_Assets),3))
colnames(rmse_l) <- c("RMSE_l")

resid_m <- as.matrix.data.frame(result_1$predictions$ml_m)
colnames(resid_m) <- treatments

rmse_ROA_m <- RMSE(resid_m[,1],df$ROA)
rmse_Leverage_m <- RMSE(resid_m[,2],df$Leverage)
rmse_MtB_m <- RMSE(resid_m[,3],df$Market_to_Book)
rmse_m <- rbind(rmse_ROA_m,rmse_Leverage_m,rmse_MtB_m)
colnames(rmse_m) <- c("RMSE_m")

ROA_eta_l <- result_1$params$ml_l$ROA$eta
ROA_depth_l <-result_1$params$ml_l$ROA$max_depth
ROA_eta_m <- result_1$params$ml_m$ROA$eta
ROA_depth_m <- result_1$params$ml_m$ROA$max_depth

Leverage_eta_l <- result_1$params$ml_l$Leverage$eta
Leverage_depth_l <-result_1$params$ml_l$Leverage$max_depth
Leverage_eta_m <- result_1$params$ml_m$Leverage$eta
Leverage_depth_m <- result_1$params$ml_m$Leverage$max_depth

MtB_eta_l <- result_1$params$ml_l$Market_to_Book$eta
MtB_depth_l <-result_1$params$ml_l$Market_to_Book$max_depth
MtB_eta_m <- result_1$params$ml_m$Market_to_Book$eta
MtB_depth_m <- result_1$params$ml_m$Market_to_Book$max_depth


eta_l <- rbind(ROA_eta_l,Leverage_eta_l,MtB_eta_l)
colnames(eta_l) <- c("eta_l")

depth_l <- rbind(ROA_depth_l,Leverage_depth_l,MtB_depth_l)
colnames(depth_l) <- c("depth_l")

eta_m <- rbind(ROA_eta_m,Leverage_eta_m,MtB_eta_m)
colnames(eta_m) <- c("eta_m")

depth_m <- rbind(ROA_depth_m,Leverage_depth_m,MtB_depth_m)
colnames(depth_m) <- c("depth_m")

NoInt_100 <- cbind(result_1$summary(),eta_l,depth_l,rmse_l,eta_m,depth_m, rmse_m)

## 1.3 300 trees ####

result_1 <- run_dml(ntrees=25)

result_1$summary()

rmse_l <- as.matrix(rep(RMSE(result_1$predictions$ml_l,df$RD_to_Assets),3))
colnames(rmse_l) <- c("RMSE_l")

resid_m <- as.matrix.data.frame(result_1$predictions$ml_m)
colnames(resid_m) <- treatments

rmse_ROA_m <- RMSE(resid_m[,1],df$ROA)
rmse_Leverage_m <- RMSE(resid_m[,2],df$Leverage)
rmse_MtB_m <- RMSE(resid_m[,3],df$Market_to_Book)
rmse_m <- rbind(rmse_ROA_m,rmse_Leverage_m,rmse_MtB_m)
colnames(rmse_m) <- c("RMSE_m")

ROA_eta_l <- result_1$params$ml_l$ROA$eta
ROA_depth_l <-result_1$params$ml_l$ROA$max_depth
ROA_eta_m <- result_1$params$ml_m$ROA$eta
ROA_depth_m <- result_1$params$ml_m$ROA$max_depth

Leverage_eta_l <- result_1$params$ml_l$Leverage$eta
Leverage_depth_l <-result_1$params$ml_l$Leverage$max_depth
Leverage_eta_m <- result_1$params$ml_m$Leverage$eta
Leverage_depth_m <- result_1$params$ml_m$Leverage$max_depth

MtB_eta_l <- result_1$params$ml_l$Market_to_Book$eta
MtB_depth_l <-result_1$params$ml_l$Market_to_Book$max_depth
MtB_eta_m <- result_1$params$ml_m$Market_to_Book$eta
MtB_depth_m <- result_1$params$ml_m$Market_to_Book$max_depth


eta_l <- rbind(ROA_eta_l,Leverage_eta_l,MtB_eta_l)
colnames(eta_l) <- c("eta_l")

depth_l <- rbind(ROA_depth_l,Leverage_depth_l,MtB_depth_l)
colnames(depth_l) <- c("depth_l")

eta_m <- rbind(ROA_eta_m,Leverage_eta_m,MtB_eta_m)
colnames(eta_m) <- c("eta_m")

depth_m <- rbind(ROA_depth_m,Leverage_depth_m,MtB_depth_m)
colnames(depth_m) <- c("depth_m")

NoInt_300 <- cbind(result_1$summary(),eta_l,depth_l,rmse_l,eta_m,depth_m, rmse_m)


