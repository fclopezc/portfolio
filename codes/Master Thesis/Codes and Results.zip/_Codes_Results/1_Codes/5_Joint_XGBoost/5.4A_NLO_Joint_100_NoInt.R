#########################################################################+
# LASSO: DML ############################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list = setdiff(ls(),c("results_100")))
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)

## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_2.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))


## 0.3 Assigning time ####

K <- 10
years <- sort(unique(df$fyear))
T_total <- length(years)
block_size <- floor(T_total / (K-1))

# Assign years to contiguous blocks
year_blocks <- cut(1:T_total, breaks = K, labels = FALSE)
block_mapping <- data.frame(fyear = years, block = year_blocks)
df <- df %>% left_join(block_mapping, by = "fyear")

remove(list =c("block_size","T_total","years","year_blocks",
               "block_mapping"))


## 0.4 Define quasy complement ####

get_quasi_complement <- function(k, K) {
  if (K < 3) stop("K must be >= 3 for NLO cross-fitting")
  if (k == 1) return(3:K)               # Exclude 1, 2
  if (k == 2) return(4:K)               # Exclude 2, 3
  if (k == K) return(1:(K-2))           # Exclude K-1, K
  if (k == K-1) return(1:(K-3))         # Exclude K-2, K-1
  c(1:(k-2), (k+2):K)                  # General case
}

## 0.5 Common elements among all ####

Y <- df[,c("RD_to_Assets")]
X <- df[,setdiff(names(df), 
                 c("gvkey", "fyear", "RD_to_Assets","block",
                   "ROA","Leverage","Market_to_Book"))]
controls <- as.matrix(X)

###########################################################+
# 1. ROA ##################################################
###########################################################+

## 1.1 Defining variables #####

D <- df[,c("ROA")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 1.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Convert data to DMatrix format (required by xgboost)
  dtrain_Y <- xgb.DMatrix(data = controls[train, ], label = Y[train])
  dtrain_D <- xgb.DMatrix(data = controls[train, ], label = D[train])
  dtest <- xgb.DMatrix(data = controls[test, ])
  
  # Outcome model (Y ~ X) with XGBoost
  fit.xgb.Y <- xgb.train(
    data = dtrain_Y,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Ytilde[test] <- Y[test] - predict(fit.xgb.Y, dtest)
  
  # Treatment model (D ~ X) with XGBoost
  fit.xgb.D <- xgb.train(
    data = dtrain_D,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Dtilde[test] <- D[test] - predict(fit.xgb.D, dtest)
}

## 1.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
ROA_NLO_CV <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

###########################################################+
# 2. Leverage ##################################################
###########################################################+

## 2.1 Defining variables #####

D <- df[,c("Leverage")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 2.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Convert data to DMatrix format (required by xgboost)
  dtrain_Y <- xgb.DMatrix(data = controls[train, ], label = Y[train])
  dtrain_D <- xgb.DMatrix(data = controls[train, ], label = D[train])
  dtest <- xgb.DMatrix(data = controls[test, ])
  
  # Outcome model (Y ~ X) with XGBoost
  fit.xgb.Y <- xgb.train(
    data = dtrain_Y,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Ytilde[test] <- Y[test] - predict(fit.xgb.Y, dtest)
  
  # Treatment model (D ~ X) with XGBoost
  fit.xgb.D <- xgb.train(
    data = dtrain_D,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Dtilde[test] <- D[test] - predict(fit.xgb.D, dtest)
}

## 2.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
Lev_NLO_CV <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)

beepr::beep(sound = 2)

###########################################################+
# 3. Market to Book #######################################
###########################################################+

## 3.1 Defining variables #####

D <- df[,c("Market_to_Book")]

# Preparing the list
Ytilde <- numeric(nrow(df))
Dtilde <- numeric(nrow(df))

## 3.2  Run the loop ####

for (k in 1:K) {
  qc_folds <- get_quasi_complement(k, K)
  train <- df$block %in% qc_folds
  test <- df$block == k
  
  # Skip if test set is empty
  if(sum(test) == 0) next
  
  # Convert data to DMatrix format (required by xgboost)
  dtrain_Y <- xgb.DMatrix(data = controls[train, ], label = Y[train])
  dtrain_D <- xgb.DMatrix(data = controls[train, ], label = D[train])
  dtest <- xgb.DMatrix(data = controls[test, ])
  
  # Outcome model (Y ~ X) with XGBoost
  fit.xgb.Y <- xgb.train(
    data = dtrain_Y,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Ytilde[test] <- Y[test] - predict(fit.xgb.Y, dtest)
  
  # Treatment model (D ~ X) with XGBoost
  fit.xgb.D <- xgb.train(
    data = dtrain_D,
    nrounds = 100,
    params = list(
      objective = "reg:squarederror",
      eta = 0.15,
      lambda = 1,
      max_depth = 5,
      eval_metric = "rmse"
    ),
    verbose = 0
  )
  Dtilde[test] <- D[test] - predict(fit.xgb.D, dtest)
}

## 3.3 Performing bootstrapping ####

n <- nrow(controls)

boot_estimates <- replicate(500, {
  idx <- sample(1:n, replace = TRUE)
  Yb <- Ytilde[idx]
  Db <- Dtilde[idx]
  coef(lm(Yb ~ Db - 1))
})

theta_hat_boot <- mean(boot_estimates) 
se_boot <- sd(boot_estimates) 

t_value <- theta_hat_boot / se_boot
p_value <- 2 * pt(-abs(t_value), df = n - 1)

rmse_l <- RMSE(Y, (Y + Ytilde))
rmse_m <- RMSE(D, (D + Dtilde))

# Print theresult
MtB_NLO_CV <- data.frame(
  Estimate = theta_hat_boot,
  `Std. Error` = se_boot,
  `t value` = t_value,
  `Pr(>|t|)` = p_value,
  `RMSE_l` = rmse_l,
  `RMSE_m` = rmse_m
)


beepr::beep(sound = 2)

# A. MERGING RESULTS ####

results_100 <- rbind(ROA_NLO_CV,
                     Lev_NLO_CV,
                     MtB_NLO_CV)

colnames(results_100) <- c("Estimate", "Std. Error", "t value", "Pr.Value",
                           "RMSE_l","RMSE_m")
rownames(results_100) <- c("ROA_CV_100",
                           "Leverage_CV_100",
                           "MtB_CV_100")


write.csv(results_100, "e_drafts/results/XGB/8A_NLO_Joint_100_NoInt.csv")
