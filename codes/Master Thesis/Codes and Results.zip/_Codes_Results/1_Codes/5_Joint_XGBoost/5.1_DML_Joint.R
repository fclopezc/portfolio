#########################################################################+
# XGBoost: DML ##########################################################+
#########################################################################+

# CLEANING CONSOLE ####
cat("/014")
rm(list=ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)


## 0.2 LOADING DATASET WITH VARIABLES

df <- readRDS("a_microdata/temp/Sample_2.rds")
plm::is.pbalanced(df) # check the datastill balance

# Remove the other options of Y
df <- df %>% select(-matches("RD_to_Sales|Log_RD"))

# convert `sic` into dummy

df <- cbind(
  df %>% select(-sic),
  model.matrix(~ sic - 1, data = df))

## 0.3 Define treatments ####

treatments <- c("ROA", "Leverage", "Market_to_Book")
interactions <- c("ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
y_var <- "RD_to_Assets"

## 0.4 XGBoost function ####

run_dml <- function(ntrees) {
  cat("Running DML with tuning of depth and eta\n")
  
  # Define parameter grid
  param_grid = list(
    "ml_l" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    ),
    "ml_m" = ps(
      max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
      eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
    )
  )
  
  # Base learner with fixed parameters
  #learner <- lrn("regr.xgboost",nrounds = ntrees,lambda = 1,alpha = 0)
  
  learner <- lrn("regr.xgboost",
                 nrounds = ntrees,
                 early_stopping_rounds = 10,
                 validate = 0.1,
                 lambda = 1,
                 alpha = 0)
  
  # Clone for ml_l and ml_m
  ml_l <- learner$clone()
  ml_m <- learner$clone()
  
  # Create DML object
  dml_plr <- DoubleMLPLR$new(data = dml_data, ml_l = ml_l, ml_m = ml_m, n_folds = 10)
  
  # Tune depth and eta
  set.seed(123)
  dml_plr$tune(
    param_set = param_grid,
    tune_settings = list(
      terminator = trm("evals", n_evals = 10),
      algorithm = tnr("random_search"),
      rsmp_tune = rsmp("cv", folds = 10),
      measure = list("ml_l" = msr("regr.mse"), "ml_m" = msr("regr.mse"))
    ),
    tune_on_folds = FALSE
  )
  
  dml_plr$fit(store_predictions = TRUE)
  
  # Get standard summary
  result_summary <- dml_plr$summary()
  
  beepr::beep(sound = 2)
  gc()
  
  return(model = dml_plr)
  #return(summary = result_summary)
}

## 0.5 Summary function #####

summarize_dml_results <- function(dml_result, df, treatments, model_type = "NoInt", num_trees, model_name = NULL) {
  # Calculate RMSE for ml_l predictions
  rmse_l <- as.matrix(rep(RMSE(dml_result$predictions$ml_l, df$RD_to_Assets), length(treatments)))
  colnames(rmse_l) <- c("RMSE_l")
  
  # Calculate RMSE for each treatment in ml_m predictions
  resid_m <- as.matrix.data.frame(dml_result$predictions$ml_m)
  colnames(resid_m) <- treatments
  
  rmse_m <- sapply(seq_along(treatments), function(i) {
    RMSE(resid_m[, i], df[[treatments[i]]])
  })
  rmse_m <- as.matrix(rmse_m)
  colnames(rmse_m) <- c("RMSE_m")
  
  # Extract eta and depth parameters for each treatment
  extract_params <- function(param_type, learner_type) {
    sapply(treatments, function(treatment) {
      dml_result$params[[learner_type]][[treatment]][[param_type]]
    })
  }
  
  eta_l <- as.matrix(extract_params("eta", "ml_l"))
  colnames(eta_l) <- c("eta_l")
  
  depth_l <- as.matrix(extract_params("max_depth", "ml_l"))
  colnames(depth_l) <- c("depth_l")
  
  eta_m <- as.matrix(extract_params("eta", "ml_m"))
  colnames(eta_m) <- c("eta_m")
  
  depth_m <- as.matrix(extract_params("max_depth", "ml_m"))
  colnames(depth_m) <- c("depth_m")
  
  # Combine all results
  result_table <- cbind(
    dml_result$summary(),
    eta_l,
    depth_l,
    rmse_l,
    eta_m,
    depth_m,
    rmse_m
  )
  
  # Rename rows according to specified format
  new_rownames <- paste(model_type, num_trees, rownames(result_table), sep = "_")
  rownames(result_table) <- new_rownames
  
  # Assign to a variable if model_name is provided
  if (!is.null(model_name)) {
    assign(model_name, result_table, envir = .GlobalEnv)
  }
  
  return(result_table)
}

#########################################################################+
# NO INTERACTIONS ########################################################
#########################################################################+

## 1.0 Creating the object #####

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df),
  y_col = "RD_to_Assets",
  d_cols = treatments,
  x_cols = setdiff(names(df), 
                   c("gvkey", "fyear","RD_to_Assets",treatments))
)

## 1.1 100 trees ####

result_1 <- run_dml(ntrees=100)

summarize_dml_results(dml_result = result_1, df = df, treatments = treatments,
  model_type = "NoInt",  num_trees = 100, model_name = "NoInt_100")


## 1.2 300 trees ####

result_2 <- run_dml(ntrees=300)

summarize_dml_results(dml_result = result_2, df = df, treatments = treatments,
                      model_type = "NoInt",  num_trees = 300, model_name = "NoInt_300")

#########################################################################+
# INTERACTIONS ###########################################################
#########################################################################+

## 2.0 Creating the object #####

df_inter <- df %>%
  mutate(ROA.Leverage = ROA * Leverage,
         ROA.Market_to_Book = ROA * Market_to_Book,
         Leverage.Market_to_Book = Leverage * Market_to_Book)

treatments_inter <- c(treatments, "ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
x_cols <- setdiff(names(df_inter), c("gvkey", "fyear", y_var, treatments_inter))

dml_data <- DoubleMLData$new(
  data = data.table::as.data.table(df_inter),
  y_col = "RD_to_Assets",
  d_cols = treatments_inter,
  x_cols = setdiff(names(df_inter), 
                   c("gvkey", "fyear","RD_to_Assets",treatments_inter))
)

## 2.1 100 trees ####

result_3 <- run_dml(ntrees=100)

summarize_dml_results(dml_result = result_3, df = df_inter, treatments = treatments_inter,
                      model_type = "Int",  num_trees = 100, model_name = "Int_100")

## 2.2 300 trees ####

result_4 <- run_dml(ntrees=300)

summarize_dml_results(dml_result = result_4, df = df_inter, treatments = treatments_inter,
                      model_type = "Int",  num_trees = 300, model_name = "Int_300")

#########################################################################+
# MERGE ##################################################################
#########################################################################+

results <- rbind(NoInt_100,NoInt_300,Int_100,Int_300)

results_temp <- rbind(NoInt_100,NoInt_300,Int_100)

write.csv(results_temp, "e_drafts/results/XGB/5A_DML_Joint_temp.csv")

write.csv(results, "e_drafts/results/XGB/5_DML_Joint.csv")
