#########################################################################+
# XGBoost: DML - Improved Version #######################################
#########################################################################+

# CLEANING CONSOLE ####
cat("\014")
rm(list=ls())
gc()

# 0. General ####

## 0.1 LOADING LIBRARIES ####
source("c_code/0_Libraries.R")
future::plan("multisession", workers = availableCores() - 1)
#future::plan("multicore", workers = availableCores() - 1)

## 0.2 LOADING AND PREPARING DATASET ####
prepare_data <- function(add_interactions = FALSE) {
  df <- readRDS("a_microdata/temp/Sample_3.rds")
  plm::is.pbalanced(df) # check the data still balance
  
  # Remove the other options of Y
  df <- df %>% select(-matches("RD_to_Sales|Log_RD"))
  
  # Convert `sic` into dummy
  df <- cbind(
    df %>% select(-sic),
    model.matrix(~ sic - 1, data = df))
  
  if (add_interactions) {
    df <- df %>%
      mutate(ROA.Leverage = ROA * Leverage,
             ROA.Market_to_Book = ROA * Market_to_Book,
             Leverage.Market_to_Book = Leverage * Market_to_Book,
             bar_ROA.Leverage = bar_ROA * bar_Leverage,
             bar_ROA.Market_to_Book = bar_ROA * bar_Market_to_Book,
             bar_Leverage.Market_to_Book = bar_Leverage * bar_Market_to_Book)
  }
  
  setDT(df)
  return(df)
}

## 0.3 Enhanced XGBoost function ####
run_dml <- function(data, y_col, d_cols, dbar_cols, ntrees, model_name = "") {
  tryCatch({
    cat(paste0("Running DML for ", model_name, "\n"))
    
    # Define parameter grid
    param_grid = list(
      "ml_l" = ps(
        max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
        eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
      ),
      "ml_m" = ps(
        max_depth = p_int(lower = 1, upper = 4, trafo = function(x) c(1, 2, 3, 5)[x]),
        eta = p_int(lower = 1, upper = 5, trafo = function(x) c(0.01, 0.05, 0.1, 0.15, 0.2)[x])
      )
    )
    
    # Base learner with fixed parameters
    learner <- lrn("regr.xgboost",
                   nrounds = ntrees,
                   early_stopping_rounds = 10,
                   validate = 0.1,
                   lambda = 1,
                   alpha = 0)
    
    # Clone for ml_l and ml_m
    ml_l <- learner$clone()
    ml_m <- learner$clone()
    
    # Create DML object
    dml_plr <- dml_cre_plr$new(data,
                               ml_l = ml_l, ml_m = ml_m,
                               score = "orth-PO",
                               dml_procedure = "dml2",
                               dml_approach  = "cre",
                               n_folds = 10)
    
    # Tune depth and eta
    set.seed(123)
    dml_plr$tune(
      param_set = param_grid,
      tune_settings = list(
        terminator = trm("evals", n_evals = 10),
        algorithm = tnr("random_search"),
        rsmp_tune = rsmp("cv", folds = 10),
        measure = list("ml_l" = msr("regr.mse"), "ml_m" = msr("regr.mse"))
      ),
      tune_on_folds = FALSE
    )
    
    dml_plr$fit(store_predictions = TRUE)
    
    # Get standard summary
    result_summary <- dml_plr$summary()
    
    # Get tuned parameters
    params_l <- dml_plr$params$ml_l[[dml_plr$data$d_cols]]
    params_m <- dml_plr$params$ml_m[[dml_plr$data$d_cols]]
    
    # Calculate RMSE for nuisance functions
    preds_l <- dml_plr$predictions$ml_l
    preds_m <- dml_plr$predictions$ml_m
    y <- dml_plr$data$data[[dml_plr$data$y_col]]
    d <- dml_plr$data$data[[dml_plr$data$d_cols]]
    
    rmse_l <- RMSE(preds_l, y)
    rmse_m <- RMSE(preds_m, d)
    rmse_model <- as.matrix(dml_plr$model_rmse)
    
    # Create enhanced summary
    enhanced_summary <- data.frame(
      Model = model_name,
      Estimate = result_summary[1, 1],
      Std.Error = result_summary[1, 2],
      t.value = result_summary[1, 3],
      p.value = result_summary[1, 4],
      depth_l = params_l$max_depth,
      eta_l = params_l$eta,
      rmse_l = rmse_l,
      depth_m = params_m$max_depth,
      eta_m = params_m$eta,
      rmse_m = rmse_m,
      rmse_model = rmse_model,
      ntrees = ntrees,
      stringsAsFactors = FALSE
    )
    
    print(enhanced_summary)
    beepr::beep(sound = 2)
    gc()
    
    return(list(model = dml_plr, summary = enhanced_summary))
  }, error = function(e) {
    message(paste("Error in model", model_name, ":", e$message))
    return(NULL)
  })
}

## 0.4 Function to run all models ####
run_all_models <- function(df, ntrees, suffix, add_interactions = FALSE) {
  # Define common parameters
  exclude_cols <- c("gvkey", "fyear", "RD_to_Assets",
                    "ROA", "Leverage", "Market_to_Book")
  
  if (add_interactions) {
    exclude_cols <- c(exclude_cols, 
                      "ROA.Leverage", "ROA.Market_to_Book", "Leverage.Market_to_Book")
  }
  
  bar_cols <- grep("^bar_", names(df), value = TRUE)
  x_cols <- setdiff(names(df), c(exclude_cols, bar_cols))
  
  xbar_cols <- bar_cols[!bar_cols %in% c("bar_RD_to_Assets", "bar_ROA",
                                         "bar_Leverage", "bar_Market_to_Book")]
  
  if (add_interactions) {
    xbar_cols <- xbar_cols[!xbar_cols %in% c("bar_ROA.Leverage", 
                                             "bar_ROA.Market_to_Book",
                                             "bar_Leverage.Market_to_Book")]
  }
  
  # Define models to run
  models <- list(
    list(y_col = "RD_to_Assets", d_cols = "ROA", dbar_cols = "bar_ROA", name = "ROA"),
    list(y_col = "RD_to_Assets", d_cols = "Leverage", dbar_cols = "bar_Leverage", name = "Leverage"),
    list(y_col = "RD_to_Assets", d_cols = "Market_to_Book", dbar_cols = "bar_Market_to_Book", name = "MtB")
  )
  
  if (add_interactions) {
    models <- c(models, list(
      list(y_col = "RD_to_Assets", d_cols = "ROA.Leverage", dbar_cols = "bar_ROA.Leverage", name = "ROA.Leverage"),
      list(y_col = "RD_to_Assets", d_cols = "ROA.Market_to_Book", dbar_cols = "bar_ROA.Market_to_Book", name = "ROA.Market_to_Book"),
      list(y_col = "RD_to_Assets", d_cols = "Leverage.Market_to_Book", dbar_cols = "bar_Leverage.Market_to_Book", name = "Leverage.Market_to_Book")
    ))
  }
  
  # Run all models
  results <- lapply(models, function(m) {
    dml_data <- dml_cre_data_from_data_frame(
      df,
      x_cols = x_cols,
      y_col = m$y_col,
      d_cols = m$d_cols,
      xbar_cols = xbar_cols,
      dbar_cols = m$dbar_cols,
      cluster_cols = "gvkey"
    )
    
    model_name <- paste0(ifelse(add_interactions, "Int_", "NoInt_"), 
                         ntrees, "_", m$name)
    
    set.seed(123)
    run_dml(dml_data, m$y_col, m$d_cols, m$dbar_cols, ntrees, model_name)
  })
  
  # Extract summaries
  summaries <- lapply(results, function(x) if (!is.null(x)) x$summary else NULL)
  summaries <- do.call(rbind, summaries[!sapply(summaries, is.null)])
  
  return(summaries)
}

##############################################################################+
# MAIN EXECUTION ####

# 1. Run models without interactions
df_no_int <- prepare_data(add_interactions = FALSE)
NoInt_100 <- run_all_models(df_no_int, 100, "100")
NoInt_300 <- run_all_models(df_no_int, 300, "300")

# 2. Run models with interactions
df_int <- prepare_data(add_interactions = TRUE)
Int_100 <- run_all_models(df_int, 100, "100", add_interactions = TRUE)
Int_300 <- run_all_models(df_int, 300, "300", add_interactions = TRUE)

# 3. Combine all results
all_results <- rbind(NoInt_100, NoInt_300, Int_100, Int_300)

# 4. Save results
write.csv(all_results, "e_drafts/results/XGB/6_CRE_Joint.csv")